package Abstract;


abstract class Language{
    public void display(){
        System.out.println("This is Abstract class Method");
    }
}
public class AbstractClassAndMethod extends Language{
    public static void main(String[] args) {

        AbstractClassAndMethod obj = new AbstractClassAndMethod();
        obj.display();

        Dog d = new Dog();

        d.makeSound();
        d.display();

        Cat c = new Cat();

        c.makeSound();
        c.display();

    }
}

abstract class Animal{
    abstract void makeSound();

    public void display(){
        System.out.println("I can eat.");
    }
}

class Dog extends Animal{
    public void makeSound(){
        System.out.println("Bark bark");
    }
}

class Cat extends Animal{
    public void makeSound(){
        System.out.println("Meows !!");
    }
}



