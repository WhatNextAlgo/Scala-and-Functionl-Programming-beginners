package optional;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class _Optional {
    public static void main(String[] args) {
//        Supplier<IllegalStateException> exception = () -> new IllegalStateException("exception");
//        Object value = Optional.ofNullable(null)
//                .orElseThrow(exception);
//
//        System.out.println(value);

//        Consumer<Object> println = email -> System.out.println("Sending email to "+ email);
//        Optional.ofNullable(null)
//                .ifPresent(println);

        Optional.ofNullable(null)
                .ifPresentOrElse(email -> System.out.println("Sending email to "+ email),
                        () ->{
                            System.out.println("Cannot Send Email");
                        });
    }
}
