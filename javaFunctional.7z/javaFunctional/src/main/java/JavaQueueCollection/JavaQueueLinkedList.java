package JavaQueueCollection;

import java.util.Queue;
import java.util.LinkedList;
public class JavaQueueLinkedList {
    public static void main(String[] args) {

        Queue<Integer> numbers = new LinkedList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);

        System.out.println("Numbers "+ numbers );

        int head = numbers.peek();
        System.out.println("Peek " + head);

        int remove_head = numbers.poll();
        System.out.println("remove head " + remove_head);



    }
}
