package JavaQueueCollection;
import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Deque;

public class JavaDequeue {
    public static void main(String[] args) {
        Deque<Integer> numbers = new ArrayDeque<>();
        numbers.offer(1);
        numbers.addFirst(2);
        numbers.addFirst(3);
        numbers.addLast(5);
        System.out.println("Deque Number "+ numbers);

        int firstElement = numbers.peekFirst();
        System.out.println("First Element: " + firstElement);

        int lastElement = numbers.peekLast();
        System.out.println("Last Element: " + lastElement);

        // Remove elements from the Deque
        int removedNumber1 = numbers.pollFirst();
        System.out.println("Removed First Element: " + removedNumber1);

        int removedNumber2 = numbers.pollLast();
        System.out.println("Removed Last Element: " + removedNumber2);

        System.out.println("Updated Deque: " + numbers);
    }
}
