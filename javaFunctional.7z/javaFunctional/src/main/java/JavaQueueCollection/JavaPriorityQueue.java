package JavaQueueCollection;

import com.sun.source.tree.WhileLoopTree;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Iterator;

public class JavaPriorityQueue {
    public static void main(String[] args) {
        PriorityQueue<Integer> numbers = new PriorityQueue<>(new CustomComparator());

        numbers.offer(5);
        numbers.offer(3);
        numbers.offer(2);

        System.out.println("numbers "+ numbers);

        // Access elements of the Queue
        int accessedNumber = numbers.peek();
        System.out.println("Accessed Element: " + accessedNumber);

        // Remove elements from the Queue
        int removedNumber = numbers.poll();
        System.out.println("Removed Element: " + removedNumber);

        System.out.println("Updated Queue: " + numbers);


        //Priority Queue
        PriorityQueue<String> p = new PriorityQueue<>();
        p.offer("Cars");
        p.offer("Bike");
        p.offer("Airplane");

        System.out.println("Priority Queue "+ p);

        Iterator<String> iterate = p.iterator();

        while (iterate.hasNext()){
            System.out.print(iterate.next());
            System.out.print(", ");

        }



    }
}
class CustomComparator implements Comparator<Integer>{
    @Override
    public int compare(Integer number1,Integer number2){
        int value = number1.compareTo(number2);
        if (value > 0){
            return -1;
        }
        else if (value < 0){
            return 1;
        }
        else{
            return 0;
        }

    }
}
