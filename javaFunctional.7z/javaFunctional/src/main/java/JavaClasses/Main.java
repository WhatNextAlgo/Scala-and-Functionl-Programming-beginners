package JavaClasses;

public class Main {
    public static void main(String[] args) {

        //Create objects of Lamp
        Lamp led = new Lamp();
        Lamp halogen = new Lamp();
        //Turn on the light by
        led.turnOn();

        //Turn off the light by
        halogen.turnOff();

        //language
        Language lang = new Language();
        lang.getName();

        Language lang1 = new Language("Python");
        lang1.getName();

        //Concat two string
        String first = "Java";
        String second = " Programming";

        System.out.println(first.concat(second));


    }

    static class Lamp{

        boolean isOn;

        public void turnOn(){
            isOn = true;
            System.out.println("Light On? "+ isOn);
        }

        public void turnOff(){
            isOn = false;
            System.out.println("Light On? " + isOn);
        }

    }

    static class Language{
        String language;

        //Default Constructor
        Language(){
            //Constructor call another constructor.
            this("Java");
            //this.language = "Java";
        }
        //Constructor with parameter

        Language(String language){
            this.language = language;

        }
        public void getName(){
            System.out.println("Programming Language :" +this.language);
        }
    }

}
