package JavaStream;
import java.io.*;

public class JavaObjectInputStream {
    public static void main(String[] args) {
        int data1 = 5;
        String data2 = "This is programiz";
        String data3 = "This is Java Programming";
        try{
//            FileOutputStream file = new FileOutputStream("src/main/java/JavaStream/output.txt");
//            ObjectOutputStream output = new ObjectOutputStream(file);
//            // Writing to the file using ObjectOutputStream
//            output.writeInt(data1);
//            output.writeObject(data2);
//            output.writeObject(data3);
//
//
//            FileInputStream fileStream = new FileInputStream("src/main/java/JavaStream/output.txt");
//            // Creating an object input stream
//            ObjectInputStream objStream = new ObjectInputStream(fileStream);
//
//            //Using the readInt() method
//            System.out.println("Integer data :" + objStream.readInt());
//
//            // Using the readObject() method
//            System.out.println("String data: " + objStream.readObject());
//            // Using the readObject() method
//            System.out.println("String data: " + objStream.readObject());
//
//            output.close();
//            objStream.close();
            Dog dog = new Dog("tyson","German Shephred");
            FileOutputStream file  =  new FileOutputStream("src/main/java/JavaStream/output.txt");
            ObjectOutputStream output  =  new ObjectOutputStream(file);
            // Writing to the file using ObjectOutputStream
            output.writeObject(dog);

            FileInputStream fileStream = new FileInputStream("src/main/java/JavaStream/output.txt");
            // Creating an object input stream
            ObjectInputStream objStream = new ObjectInputStream(fileStream);

            Dog newDog = (Dog)objStream.readObject();
            System.out.println("Dog Name: " + newDog.name);
            System.out.println("Dog Breed: " + newDog.breed);

            output.close();
            objStream.close();

        }catch (Exception e){
            System.out.println("Exception : "+e);

        }
    }
}

class Dog implements Serializable{
    String name;
    String breed;

    Dog(String name,String breed){
        this.name = name;
        this.breed = breed;

    }
}
