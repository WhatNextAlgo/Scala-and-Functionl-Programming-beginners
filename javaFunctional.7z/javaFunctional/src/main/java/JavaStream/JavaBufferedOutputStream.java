package JavaStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
public class JavaBufferedOutputStream {
    public static void main(String[] args) {

        String data = "This is a demo of the flush method";

        try {
            // Creates a FileOutputStream
            FileOutputStream file = new FileOutputStream("src/main/java/JavaStream/file.txt");

            // Creates a BufferedOutputStream
            BufferedOutputStream output = new BufferedOutputStream(file);

            byte[] array = data.getBytes();

            // Writes data to the output stream
            output.write(array);
            // Flushes data to the destination
            output.flush();
            System.out.println("Data is flushed to the file.");
            output.close();
        }

        catch (Exception e) {
            e.getStackTrace();
        }
    }
}
