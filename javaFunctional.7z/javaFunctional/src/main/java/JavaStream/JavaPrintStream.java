package JavaStream;
import java.io.PrintStream;

public class JavaPrintStream {
    public static void main(String[] args) {
        try{
            PrintStream out = new PrintStream("src/main/java/JavaStream/output.txt");
            int age = 25;
            out.printf("I am %d years old",age);
            out.close();
        }catch (Exception e){
            System.out.println(e);
        }

    }
}
