package JavaStream;
import java.io.FileOutputStream;
public class JavaFileOutputStream {
    public static void main(String[] args) {
        try{
            String data = "First time running FileOutputStream";
            FileOutputStream output = new FileOutputStream("src/main/java/JavaStream/output.txt");
            byte[] dataBytes = data.getBytes();
            output.write(dataBytes);
            // Using the flush() method
            output.flush();

            output.close();
        }
        catch (Exception e){
            System.out.println("Exception : "+e);
        }
    }
}
