package JavaStream;
import java.io.File;
import java.io.FileInputStream;
public class JavaFileInputStream {
    public static void main(String[] args) {
        try{
            FileInputStream input = new FileInputStream("src/main/java/JavaStream/input.txt");

            int i = input.read();

            while (i != -1){
                System.out.print((char) i);
                i = input.read();
            }


            input.close();
        }
        catch (Exception e){
            System.out.println("Exception : "+ e);
        }



    }
}
