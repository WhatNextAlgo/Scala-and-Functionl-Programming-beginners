package JavaStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class JavaOutputStreamClass {
    public static void main(String[] args) {
        String data = "This is java output stream class";
        try{
            OutputStream output = new FileOutputStream("src/main/java/JavaStream/output.txt");
            //Convert string to bytes
            byte[] dataBytes = data.getBytes();
            output.write(dataBytes);
            System.out.println("Data is written to the file.");

            // Closes the output stream
            output.close();
        }
        catch (Exception e){
            System.out.println("Exception : "+e);
        }

    }
}
