package JavaStream;
import java.io.ByteArrayOutputStream;
public class JavaByteArrayOutputStream {
    public static void main(String[] args) {
        String data = "This is a line of text inside the string.";
        try{
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] array = data.getBytes();
            // Writes data to the output stream
            output.write(array);
            // Retrieves data from the output stream in string format
            String streamData = output.toString();
            System.out.println("Output stream: " + streamData);

            // Returns an array of bytes
            byte[] byteData = output.toByteArray();
            System.out.print("Data using toByteArray(): ");
            for(int i=0; i<byteData.length; i++) {
                System.out.print((char)byteData[i]);
            }

            // Returns a string
            String stringData = output.toString();
            System.out.println("\nData using toString(): " + stringData);


            output.close();


        }catch (Exception e){
            System.out.println("Exception : "+ e.getStackTrace());
        }

    }
}
