package JavaStream;
import java.io.ByteArrayInputStream;
public class JavaByteArrayInputStream {
    public static void main(String[] args) {
        byte[] array = {1,2,3,4,5};
        try{
            ByteArrayInputStream input = new ByteArrayInputStream(array);
            System.out.print("The bytes read from the input stream: ");

            for (int i=0;i < array.length;i++){
                int data = input.read();
                System.out.print(data + ", ");
            }
            input.close();

        }catch(Exception e){
            System.out.println("Exception : "+ e.getStackTrace());
        }

    }
}
