package JavaMap;
import java.util.EnumMap;
public class JavaEnumMap {
    public static void main(String[] args) {
        EnumMap<Size,Integer> sizes1 = new EnumMap<>(Size.class);
        //Using put method
        sizes1.put(Size.SMALL,28);
        sizes1.put(Size.MEDIUM,32);
        System.out.println("EnumMap1: " + sizes1);

        EnumMap<Size, Integer> sizes2 = new EnumMap<>(Size.class);

        // Using the putAll() Method
        sizes2.putAll(sizes1);
        sizes2.put(Size.LARGE, 36);
        System.out.println("EnumMap2: " + sizes2);

        // Using the entrySet() Method
        System.out.println("Key/Value mappings: " + sizes2.entrySet());

        // Using the keySet() Method
        System.out.println("Keys: " + sizes2.keySet());

        // Using the values() Method
        System.out.println("Values: " + sizes2.values());

    }
}

enum Size{
    SMALL, MEDIUM, LARGE, EXTRALARGE
}
