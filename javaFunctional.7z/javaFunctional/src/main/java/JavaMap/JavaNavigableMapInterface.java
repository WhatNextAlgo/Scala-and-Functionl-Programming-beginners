package JavaMap;
import java.util.NavigableMap;
import java.util.TreeMap;

public class JavaNavigableMapInterface {
    public static void main(String[] args) {
        NavigableMap<String, Integer> numbers = new TreeMap<>();

        // Insert elements to map
        numbers.put("Two", 2);
        numbers.put("One", 1);
        numbers.put("Three", 3);
        System.out.println("NavigableMap: " + numbers);

        // Access the first entry of the map
        System.out.println("First Entry: " + numbers.firstEntry());

        // Access the last entry of the map
        System.out.println("Last Entry: " + numbers.lastEntry());

        // Remove the first entry from the map
        System.out.println("Removed First Entry: " + numbers.pollFirstEntry());

        // Remove the last entry from the map
        System.out.println("Removed Last Entry: " + numbers.pollLastEntry());
        //Reverse a Map
        numbers.put("Five", 5);
        numbers.put("Six", 6);
        numbers.put("Seven", 7);
        System.out.println("with out descendingMap : "+numbers);
        System.out.println("with descendingMap  : "+numbers.descendingMap());

    }
}
