package JavaMap;
import com.sun.security.jgss.GSSUtil;

import java.util.HashMap;
import java.util.Map.Entry;

public class JavaHashMap {
    public static void main(String[] args) {

        HashMap<String,Integer> numbers = new HashMap<>();
        numbers.put("Java",8);
        numbers.put("Python",3);
        numbers.put("JavaScript",1);

        System.out.println("HashMap : "+numbers);
        // get() method to get value
        int value = numbers.get("Java");
        System.out.println("Get the value of key = Java and value = " + value);

        //Change the value in hashMap
        numbers.replace("JavaScript",5);
        System.out.println("HashMap : "+numbers);

        //Remove the key from HashMap
        int removedValue = numbers.remove("Python");
        System.out.println("Removed value : "+ removedValue);

        // iterate through keys only
        for(String key : numbers.keySet()){
            System.out.println("Key : "+ key);
        }

        // iterate through values only
        for(int val : numbers.values()){
            System.out.println("Key : "+ val);
        }

        // iterate through values only
        for(Entry<String,Integer> entry : numbers.entrySet()){
            System.out.println("Key=Value : "+ entry);
        }
    }
}
