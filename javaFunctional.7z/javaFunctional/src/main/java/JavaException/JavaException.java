package JavaException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class JavaException {
    public static void main(String[] args) {
        try{

            findFile();

            int[] number = {1,2,3,4,5};

            for (int i = 0;i <= number.length;i++){
                System.out.println("Num => "+number[i]);
            }

        }
        catch (IOException e){
            System.out.println("IOException => "+ e);
        }
        catch (Exception e){
            System.out.println("Exception => "+ e.getMessage());
        }
        finally {
            System.out.println("We are handling Exception and IOException");
        }
    }

    public static void findFile() throws IOException{
        File file = new File("text.txt");
        FileInputStream stream = new FileInputStream(file);
    }
}


