package JavaAnonymous;

public class JavaAnonymous {
    public static void main(String[] args) {
        AnonymousDemo an = new AnonymousDemo();
        an.createClass();
    }
}
class Polygon{
    public void display(){
        System.out.println("I'm a polygon.");
    }
}
class AnonymousDemo {

    public void createClass() {
        // creation of anonymous class extending class Polygon

        Polygon p1 = new Polygon() {
            public void display() {
                System.out.println("Inside an anonymous class.");
            }
        };
        p1.display();
    }
}
