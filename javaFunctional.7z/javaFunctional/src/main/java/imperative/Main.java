package imperative;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static imperative.Main.Gender.*;

public class Main {
    public static void main(String[] args) {
        List<Person> peoples = List.of(
                new Person("John",MALE),
                new Person("Maria",FEMALE),
                new Person("Aisha",FEMALE),
                new Person("Ali",MALE),
                new Person("Alice",FEMALE)

        );

        //Imperative approach
        System.out.println("Imperative approach");
        List<Person> females = new ArrayList<>();

        for (Person person : peoples){
            if (FEMALE.equals(person.gender)){
                females.add(person);
            }
        }

        for (Person female:females){
            System.out.println(female);
        }
        //Declarative approach
        System.out.println("Declarative approach");
        //PREDICATE
        Predicate<Person> personPredicate = person -> FEMALE.equals(person.gender);


        List<Person> females2 = peoples.stream().filter(personPredicate).collect(Collectors.toList());
        females2.forEach(System.out::println);

    }

    //PERSON CLASS

    static class Person{
        private  final  String name;
        private final Gender gender;

        Person(String name,Gender gender){
            this.name = name;
            this.gender = gender;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", gender=" + gender +
                    '}';
        }
    }
    //ENUM
    enum  Gender{
        MALE,FEMALE
    }
}
