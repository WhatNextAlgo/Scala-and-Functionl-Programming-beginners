package functionInterface;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class _Consumer {
    public static void main(String[] args) {

        Customer cust = new Customer("sumit","8080434231");
        greetCustomer(cust);
        //Function Interface
        greetCustomerConsumer.accept(cust);

        //BiConsumer
        greetCustomerConumerV2.accept(cust,false);

    }

    //BiConsumer

    static BiConsumer<Customer,Boolean> greetCustomerConumerV2 = ((customer, showPhoneNUmber) ->
            System.out.println(
                    "Hello " + customer.customerName + ", thanks for registering phone numner "
                            + (showPhoneNUmber ?customer.customerPhoneName: "***********")
            )
    );

    static Consumer<Customer> greetCustomerConsumer = customer ->
            System.out.println(
            "Hello " + customer.customerName + ", thanks for registering phone numner "
                    + customer.customerPhoneName
    );

    static void greetCustomer(Customer customer){
        System.out.println(
                "Hello " + customer.customerName + ", thanks for registering phone numner "
                + customer.customerPhoneName
        );

    }
    static class Customer{
        private final String customerName;
        private final String customerPhoneName;

        Customer(String customerName,String customerPhoneName){
            this.customerName =customerName;
            this.customerPhoneName = customerPhoneName;

        }
    }
}
