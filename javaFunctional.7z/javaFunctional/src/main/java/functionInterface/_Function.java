package functionInterface;

import java.time.temporal.UnsupportedTemporalTypeException;
import java.util.function.BiFunction;
import java.util.function.Function;

public class _Function {

    public static void main(String[] args) {
        int increment = increment(0);
        //System.out.println(increment);

        //FUNCTION
        System.out.println("FUNCTION <T,R>");
        System.out.println(incrementByOneFunction.apply(1));

        int multiply = multiplyBy10.apply(10);
        //System.out.println(multiply);

        Function<Integer, Integer> addByOneAndThenMultiplyBy10 = incrementByOneFunction.andThen(multiplyBy10);
        System.out.println(addByOneAndThenMultiplyBy10.apply(10));

        System.out.println("BiFunction");
        int increByOneAndMul = incrementByOneAndMultiplyBy.apply(1,500);
        System.out.println(increByOneAndMul);

    }
    static Function<Integer,Integer> incrementByOneFunction = number -> number + 1;
    static Function<Integer,Integer> multiplyBy10 = number -> number * 10;

    static BiFunction<Integer,Integer,Integer> incrementByOneAndMultiplyBy =
            (numToIncrementByOne,multiplyBy) -> (numToIncrementByOne+1) * multiplyBy;




    static int increment(int number){
        return number + 1;
    }
}
