package functionInterface;

import java.util.function.Supplier;

public class _Supplier {
    public static void main(String[] args) {
        //Normal Java
        System.out.println(getDbConnectionUrl());

        //Supplier
        System.out.println(getDbUrl.get());

    }

    static String getDbConnectionUrl(){
        return "jdbc://localhost:5432/users";
    }

    static Supplier<String> getDbUrl = () ->"jdbc://localhost:5432/users";
}
