package functionInterface;

import java.util.function.Predicate;

public class _Predicate {
    public static void main(String[] args) {
        System.out.println("Normal Java");
        System.out.println(isPhoneNumberValid("07999999999"));
        System.out.println(isPhoneNumberValid("0799999999"));
        System.out.println(isPhoneNumberValid("09999999999"));

        //Predicate
        System.out.println("Predicate");
        System.out.println(isPhoneNumberValidPredicate.test("07999999999"));
        System.out.println(isPhoneNumberValidPredicate.test("09999999999"));

        System.out.println("Is phone number valid and contain no.3 "+
                isPhoneNumberValidPredicate.and(containNum3).test("07999939999")
        );

    }

    static Predicate<String> isPhoneNumberValidPredicate = phoneNumber ->
            phoneNumber.startsWith("07") && phoneNumber.length() == 11;

    static Predicate<String> containNum3 =  phoneNumber ->
            phoneNumber.contains("3");

    static boolean isPhoneNumberValid(String phoneNumber){
        return phoneNumber.startsWith("07") && phoneNumber.length() == 11;
    }
}
