package JavaCollectionInterface;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
public class JavaList {
    public static void main(String[] args) {

        List<Integer> numbers = new ArrayList<Integer>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        System.out.println("List :"+numbers);
        int removedNumber = numbers.remove(2);
        System.out.println("removed from ArrayList :"+removedNumber);

        List<Integer> num = new LinkedList<>();
        num.add(1);
        num.add(2);
        num.add(3);
        System.out.println("List :"+num);
        int removedNum = num.remove(2);
        System.out.println("removed from LinkedList :"+removedNum);



    }
}
