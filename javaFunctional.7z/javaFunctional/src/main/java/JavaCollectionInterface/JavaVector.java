package JavaCollectionInterface;
import java.util.Iterator;
import java.util.Vector;
public class JavaVector {
    public static void main(String[] args) {
        Vector<String> animal = new Vector<>();
        animal.add("Cat");
        animal.add("Dog");
        animal.add("Horse");

        System.out.println(animal);

        // Using iterator()
        Iterator<String> iterate = animal.iterator();
        System.out.print("Vector: ");
        while(iterate.hasNext()) {
            System.out.print(iterate.next());
            System.out.print(", ");
        }
    }


}
