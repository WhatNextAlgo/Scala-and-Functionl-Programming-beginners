package JavaCollectionInterface;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class JavaArrayList {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("Java");
        arrayList.add("Python");
        arrayList.add("Scala");
        arrayList.add(1,"JavaScript");
        System.out.println("Array List :"+ arrayList);

        //Access the element of arrayList
        String str = arrayList.get(1);
        System.out.println("language :"+ str);
        //Change the element in arrayList
        arrayList.set(1,"C++");
        System.out.println("Array List :"+ arrayList);
        //// remove element from index 2

        String  removeElem = arrayList.remove(2);
        System.out.println("removed for arrayList :"+ removeElem);
        System.out.println("Array List :"+ arrayList);

        //Sort arrayList
        arrayList.sort(Comparator.naturalOrder());
        System.out.println(arrayList);

        //Conversion from ArrayList to Array
        String[] arr = new String[arrayList.size()];
        arrayList.toArray(arr);

        System.out.println("ArrayList convert to Array :"+Arrays.toString(arr));

        //Array convert ot ArrayList
        ArrayList<String> newArrayList =  new ArrayList<>(Arrays.asList(arr));
        System.out.println("Array to ArrayList :"+newArrayList);


    }
}
