package JavaCollectionInterface;

import java.util.Stack;

public class JavaStack {
    public static void main(String[] args) {
        Stack<String> animals = new Stack<>();
        animals.push("Cats");
        animals.push("Dogs");
        animals.push("Horses");

        System.out.println(animals.peek());
        System.out.println(animals.empty());
        System.out.println(animals.pop());
        System.out.println(animals.peek());

        int position =  animals.search("Dogs");
        System.out.println("position of dogs "+position);

    }
}
