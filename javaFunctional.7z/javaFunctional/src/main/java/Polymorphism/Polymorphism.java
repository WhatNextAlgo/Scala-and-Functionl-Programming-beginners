package Polymorphism;

public class Polymorphism {
    public static void main(String[] args) {
        Polygon p = new Polygon();
        p.display();

        Circle c = new Circle();
        c.display();

        Pattern d1 = new Pattern();

        // call method without any argument
        d1.display();
        System.out.println("\n");
        // call method with a single argument
        d1.display('#');
    }
}

class Polygon{
    public void display(){
        System.out.println("I'm a Polygon");
    }
}

class Circle extends Polygon{
    public void display(){
        System.out.println("I'm a Circle");
    }
}

//Polymorphism using method overloading

class Pattern{

    public void display(){
        for (int i = 0; i < 10;i++){
            System.out.print("*");
        }
    }

    public void display(char symbol){
        for (int i = 0; i<10; i++){
            System.out.print(symbol);
        }
    }
}