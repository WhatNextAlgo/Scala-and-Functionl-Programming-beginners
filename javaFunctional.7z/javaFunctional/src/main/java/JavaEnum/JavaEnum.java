package JavaEnum;

import java.util.Arrays;

public class JavaEnum {
    public static void main(String[] args) {
        Test t = new Test(Size.LARGE);
        t.orderPizza();

        System.out.println("The size of the pizza is " + Size.MEDIUM.getSize());

        Size[] enumArray = Size.values();
        System.out.println(Arrays.toString(enumArray));

        SizeOfPizza size = SizeOfPizza.SMALL;
        System.out.println(size.getSize());

        System.out.println(SizeInString.SMALL.toString());
        System.out.println(SizeInString.MEDIUM.toString());
        System.out.println(SizeInString.LARGE.toString());
        System.out.println(SizeInString.EXTRALARGE.toString());

    }
}
enum Size{
    SMALL, MEDIUM, LARGE, EXTRALARGE;

    public String getSize() {

        // this will refer to the object SMALL
        switch(this) {
            case SMALL:
                return "small";

            case MEDIUM:
                return "medium";

            case LARGE:
                return "large";

            case EXTRALARGE:
                return "extra large";

            default:
                return null;
        }
    }
}
class Test{
    Size pizzaSize;

    public Test(Size pizzaSize){
        this.pizzaSize = pizzaSize;
    }

    public void orderPizza(){
        switch (this.pizzaSize){
            case SMALL:
                System.out.println("I ordered a small size pizza.");
                break;
            case MEDIUM:
                System.out.println("I ordered a medium size pizza.");
                break;
            case LARGE:
                System.out.println("I ordered a large size pizza.");
                break;
            case EXTRALARGE:
                System.out.println("I ordered a extralarge size pizza.");
                break;
            default:
                System.out.println("Order pizza size is not available");
        }
    }
}
//enum Constructor
enum SizeOfPizza{

    //Enum constants calling the enum construnctor
    SMALL("The size is small"),
    MEDIUM("The size is medium"),
    LARGE("The size is large."),
    EXTRALARGE("The size is extra large.");

    private final String pizzaSize;

    //private enum constructor
    private SizeOfPizza(String pizzaSize){
        this.pizzaSize = pizzaSize;
    }

    public String getSize(){
        return pizzaSize;
    }

}

enum SizeInString{
    SMALL {
        @Override
        public String toString(){
            return "The size is Small";
        }
    },
    MEDIUM {
        @Override
        public String toString(){
            return "The size is Medium";
        }
    },
    LARGE {
        @Override
        public String toString(){
            return "The size is Large";
        }
    },
    EXTRALARGE {
        @Override
        public String toString(){
            return "The size is ExtraLarge";
        }
    },
}