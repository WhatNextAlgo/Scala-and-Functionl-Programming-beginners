package AccessModifier;

public class AccessModifier {

    public static void main(String[] args) {

        Data data =  new Data();
        data.setName("Programiz");
        System.out.println(data.getName());

        Complex com = new Complex(2,3);
        System.out.println(com);

        Complex com1 = new Complex(2);
        System.out.println(com1);

        Complex com2 = new Complex();
        System.out.println(com2);

        //ThisExample
        ThisExample ex = new ThisExample(1,-2);

        //Recurison
        int number = 10, result;
        Recurison r = new Recurison();
        result = r.factorial(4);
        System.out.println("factorial of "+number+" is "+ result);

        System.out.println("Sum of "+ number+" natural number is "+r.SumofNatualNumber(number));




    }

}

class Data {
    private String name;

    //Getter
    public String getName(){
        return this.name;
    }

    //Setter
    public void setName(String name) {
        this.name = name;
    }
}

class Complex{
    private int a,b;
    //Constructor with two parameter

     Complex(int a, int b){
        this.a = a;
        this.b = b;
    }
    //Constructor with one paramter
     Complex(int a){
        this(a,a);
    }
    //Constructor with no parameter

     Complex(){
        this(0);
    }

    @Override
    public String toString(){
        return this.a + " + " + this.b +"i";

    }

}

class ThisExample{
    int a;
    int b;

    ThisExample(int a, int b){
        this.a = a;
        this.b = b;

        System.out.println("Before passing this to addTwo() method:");
        System.out.println("a = "+this.a +" , b = "+ this.b);

        add(this);
        System.out.println("After passing this to addTwo() method:");
        System.out.println("a = "+this.a +" , b = "+ this.b);
    }

    void add(ThisExample o){
        o.a +=2;
        o.b +=2;

    }
}

class Recurison{

    public int factorial(int n){
        if (n != 0){
            return n * factorial(n-1);

        }
        else{
            return 1;
        }

    }
    public int SumofNatualNumber(int n){
        if (n > 0){
            return n + SumofNatualNumber(n-1);
        }
        else{
            return 0;
        }

    }
}
