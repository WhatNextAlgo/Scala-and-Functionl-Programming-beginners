package JavaAdvanceTopic;
// importing the File class
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
public class JavaFileClass {
    public static void main(String[] args) {
        // create a file object for the current location
        File file = new File("src/main/java/JavaAdvanceTopic/newFile.txt");

        try{
            boolean value = file.createNewFile();
            if (value){
                System.out.println("The new file is created.");
            }else{
                System.out.println("The file already exists.");
            }
            //File Write
            String data = "Java Programming is Awesome";
            FileWriter output = new FileWriter("src/main/java/JavaAdvanceTopic/newFile.txt");
            //write data to file
            output.write(data);
            //close the file
            output.close();

            char[] array = new char[100];
            FileReader input = new FileReader("src/main/java/JavaAdvanceTopic/newFile.txt");
            input.read(array);
            System.out.println("Data in the file:");
            System.out.println(array);
            //close the file
            input.close();

            boolean isdeleted = file.delete();
            if (isdeleted){
                System.out.println("The file is deleted");
            }else{
                System.out.println("The file is not deleted");
            }

        }catch (Exception e){
            System.out.println(e);
        }
    }
}
