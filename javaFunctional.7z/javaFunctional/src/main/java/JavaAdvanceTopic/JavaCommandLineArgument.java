package JavaAdvanceTopic;

public class JavaCommandLineArgument {
    public static void main(String[] args) {
        System.out.println("Command-Line Argument are");
        //loop through all arguments
        for(String str : args){
            System.out.println(str);
        }
    }
}
