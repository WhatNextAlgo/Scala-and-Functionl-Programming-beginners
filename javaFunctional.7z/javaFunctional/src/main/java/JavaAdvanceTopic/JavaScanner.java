package JavaAdvanceTopic;
import java.util.Scanner;
public class JavaScanner {

    public static void main(String[] args) {
        Scanner input =  new Scanner(System.in);
        System.out.println("Enter your name : ");
        String name = input.nextLine();
        input.close();
        
        


    }
}
