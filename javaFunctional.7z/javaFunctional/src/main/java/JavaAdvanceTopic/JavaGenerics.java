package JavaAdvanceTopic;

public class JavaGenerics {
    public static void main(String[] args) {
        //Initiate generic class
        //with Integer Data
        GenericsClass<Integer> intObj =  new GenericsClass<>(5);
        System.out.println("getData : "+intObj.getData());

        //Initiate generic class
        //with String Data
        GenericsClass<String> stringObj =  new GenericsClass<>("Java Programming");
        System.out.println("getData : "+stringObj.getData());

        //Generics class method
        DemoClass demo = new DemoClass();
        demo.<String>genericsMethod("Python Programming");
        demo.<Integer>genericsMethod(25);
        //GenericsClasses is bounded the Number so, integer,double, and so on.

        // create an object of GenericsClass
        GenericsClasses<Integer> obj = new GenericsClasses<>();
        obj.display();


    }
}
//Create a generic class
class GenericsClass<T>{
    //Variable of Type T
    private T data;

    public GenericsClass(T data){
        this.data =data;
    }
    //Method that return T type variable
    public T getData(){
        return this.data;
    }

}
class DemoClass{

    public <T> void genericsMethod(T data){
        System.out.println("Generics Method:");
        System.out.println("Data Passed: " + data);
    }
}

class GenericsClasses<T extends Number>{

    public void display(){
        System.out.println("This is a bounded type generics class");
    }


}