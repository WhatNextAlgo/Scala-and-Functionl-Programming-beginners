package JavaAdvanceTopic;

import java.util.ArrayList;

public class JavaAutoboxingAndUnboxing {
    public static void main(String[] args) {

        int a = 56;
        //autoboxing
        Integer aObj  = a;
        System.out.println("abj : "+ aObj );

        ArrayList<Integer> list = new ArrayList<>();
        //autoboxing
        list.add(5);
        list.add(6);
        System.out.println("List : "+list);

        //unboxing
        int b = aObj;
        // unboxing
        int c = list.get(0);
        System.out.println("Value at index 0: " + c);


    }
}
