package JavaAdvanceTopic;
import java.lang.FunctionalInterface;

import java.util.ArrayList;
import java.util.List;


public class JavaLambdaExpressions {

    // create an object of list using ArrayList
    static List<String> places = new ArrayList<>();

    // preparing our data
    public static List getPlaces(){

        // add places and country to the list
        places.add("Nepal, Kathmandu");
        places.add("Nepal, Pokhara");
        places.add("India, Delhi");
        places.add("USA, New York");
        places.add("Africa, Nigeria");

        return places;
    }
    public static void main(String[] args) {

        MyInterface ref;
        ref = () -> 3.1415;
        System.out.println("Value of Pi = " + ref.getPiValue());
        StringInterface sref = (str) ->{
            String result = "";
            for (int i = str.length()-1;i>=0;i--)
            result += str.charAt(i);
            return result;

        };

        // call the method of the interface
        System.out.println("Lambda reversed = " + sref.reverse("Lambda"));




        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("I just implemented the Runnable Functional Interface.");
            }
        }).start();


        // declare a reference to GenericInterface
        // the GenericInterface operates on String data
        // assign a lambda expression to it
        GenericInterface<String> reverse = (str) -> {

            String result = "";
            for (int i = str.length()-1; i >= 0 ; i--)
                result += str.charAt(i);
            return result;
        };

        System.out.println("Lambda reversed = " + reverse.func("Lambda"));

        // declare another reference to GenericInterface
        // the GenericInterface operates on Integer data
        // assign a lambda expression to it
        GenericInterface<Integer> factorial = (n) -> {

            int result = 1;
            for (int i = 1; i <= n; i++)
                result = i * result;
            return result;
        };

        System.out.println("factorial of 5 = " + factorial.func(5));

        List<String> myPlaces = getPlaces();
        System.out.println("Places from Nepal:");

        // Filter places from Nepal
        myPlaces.stream()
                .filter((p) -> p.startsWith("Nepal"))
                .map((p) -> p.toUpperCase())
                .sorted()
                .forEach((p) -> System.out.println(p));

    }

    @FunctionalInterface
    public  interface MyInterface{
        // the single abstract method
        double getPiValue();
    }
    @FunctionalInterface
    interface StringInterface {

        // abstract method
        String reverse(String n);
    }
    // GenericInterface.java
    @FunctionalInterface
    interface GenericInterface<T> {

        // generic method
        T func(T t);
    }
}


