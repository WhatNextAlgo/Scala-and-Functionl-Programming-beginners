package JavaAdvanceTopic;

public class JavaWrapperClass {
    public static void main(String[] args) {
        int a = 5;
        double b = 10.34343;
        //converts into wrapper objects
        Integer aObj = Integer.valueOf(a);
        Double bObj = Double.valueOf(b);

        if(aObj instanceof Integer) {
            System.out.println("An object of Integer is created.");
        }

        if(bObj instanceof Double) {
            System.out.println("An object of Double is created.");
        }

        int a1 = aObj.intValue();
        double b1 = bObj.doubleValue();
        System.out.println("a1 : "+ a1);
        System.out.println("b1 : "+ b1);
        /*
        // generates an error
        int a = null;

        // runs perfectly
        Integer a = null;

         */

    }
}
