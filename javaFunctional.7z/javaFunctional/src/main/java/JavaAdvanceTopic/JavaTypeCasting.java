package JavaAdvanceTopic;

public class JavaTypeCasting {
    public static void main(String[] args) {

        //Widening Type Casting
        //In Widening Type Casting, Java automatically converts one data type to another data type.
        // create int type variable
        int num = 10;
        System.out.println("The integer value: " + num);

        // convert into double type
        double data = num;
        System.out.println("The double value: " + data);

        //Narrowing Type Casting
        //In Narrowing Type Casting, we manually convert one data type into another using the parenthesis.
        double num1 = 10.99;
        System.out.println("The double value: " + num1);

        // convert into int type
        int data1 = (int)num1;
        System.out.println("The integer value: " + data1);

        String data2 = String.valueOf(num*100);
        System.out.println("The string value is: " + data2);

        int num3 = Integer.parseInt(data2);
        System.out.println("The integer value is: " + num3);
    }
}
