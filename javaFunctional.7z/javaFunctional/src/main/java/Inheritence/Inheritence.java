package Inheritence;

public class Inheritence {
    public static void main(String[] args) {

        Dog d = new Dog();
        d.name = "Golu";
        d.eat();
        d.bark();

        Language lang = new Language();

        lang.connectServer();
        lang.responsive("Java");




    }
}

class Animal{
    String name;

    protected void eat(){
        System.out.println("I can eat.");
    }
}

class Dog extends Animal{
    public void bark(){
        System.out.println("I can bark!!");

    }
    @Override
    public void eat(){
        System.out.println("I am a Dog");
        super.eat();
    }
}

interface Backend{
    public void connectServer();
}

class FrontEnd{
    public void responsive(String str){
        System.out.println(str + " can also used as frontend.");
    }
}

class Language extends FrontEnd implements Backend{
    String language =  "Java";
    public void connectServer(){
        System.out.println(language + " can be used as backend language.");
    }
}
