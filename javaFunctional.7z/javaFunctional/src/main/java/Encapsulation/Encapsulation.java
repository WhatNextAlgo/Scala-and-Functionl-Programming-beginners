package Encapsulation;

public class Encapsulation {
    public static void main(String[] args) {
        Person p = new Person();
        p.setAge(27);
        System.out.println(p.getAge());
    }
}

class Person{
    private int age;

    public int getAge(){
        return age;
    }

    public void setAge(int age){
        this.age = age;
    }

}
