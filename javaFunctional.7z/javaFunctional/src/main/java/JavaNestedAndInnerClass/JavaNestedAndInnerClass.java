package JavaNestedAndInnerClass;

public class JavaNestedAndInnerClass {
    public static void main(String[] args) {

        Car car1 = new Car("Mazda", "8WD");

        // create an object of inner class using the outer class
        Car.Engine engine = car1.new Engine();
        engine.setEngine();
        System.out.println("Engine Type for 8WD = " + engine.getEngineType());

        Car car2 = new Car("Crysler", "4WD");
        Car.Engine c2engine = car2.new Engine();
        c2engine.setEngine();
        System.out.println("Engine Type for 4WD = " + c2engine.getEngineType());

        // create an object of the static nested class
        // using the name of the outer class
        MotherBoard.USB usb = new MotherBoard.USB();
        System.out.println("Total Ports = " + usb.getTotalPorts());

    }
}
class Car{
    String carName;
    String carType;

    public Car(String carName,String carType){
        this.carName = carName;
        this.carType = carType;
    }
    private String getCarName(){
        return this.carName;
    }

    class Engine{
        String engineType;

        void setEngine(){

            if (Car.this.carType.equals("4WD")){
                if (Car.this.getCarName().equals("Crysler")){
                    this.engineType = "Smaller";
                }else{
                    this.engineType = "Bigger";
                }
            }
            else{
                this.engineType = "Bigger";
            }
        }

        public String getEngineType(){
            return this.engineType;
        }
    }
}
class MotherBoard {

    // static nested class
    static class USB{
        int usb2 = 2;
        int usb3 = 1;
        int getTotalPorts(){
            return usb2 + usb3;
        }
    }

}