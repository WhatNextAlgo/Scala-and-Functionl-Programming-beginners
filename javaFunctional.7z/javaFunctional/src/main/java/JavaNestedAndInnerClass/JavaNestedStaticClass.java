package JavaNestedAndInnerClass;

public class JavaNestedStaticClass {
    public static void main(String[] args) {
        // object creation of the outer class
        Animal animal = new Animal();

        //Object creation for Non Static Class
        Animal.Reptile reptile = animal.new Reptile();
        reptile.displayInfo();

        //Object creation for Static Class

        Animal.Mammal mammal = new Animal.Mammal();
        mammal.displayInfo();


    }
}

class Animal{

    //inner class
    class Reptile{
        public void displayInfo(){
            System.out.println("I'm a Reptile");
        }
    }
    //Static class
    static class Mammal{
        public void displayInfo(){
            System.out.println("I'm a Mammal");
        }
    }
}