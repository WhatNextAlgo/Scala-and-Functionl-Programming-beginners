package JavaReadWrite;
import java.io.PrintWriter;
public class JavaPrintWriter {
    public static void main(String[] args) {

        try {
            PrintWriter output = new PrintWriter("src/main/java/JavaReadWrite/output.txt");

            int age = 25;

            output.printf("I am %d years old.", age);
            output.close();
        }
        catch(Exception e) {
            e.getStackTrace();
        }
    }
}
