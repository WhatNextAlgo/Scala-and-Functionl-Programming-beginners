package JavaReadWrite;
import java.io.FileWriter;
import java.io.BufferedWriter;

public class JavaBufferedWriter {
    public static void main(String[] args) {
        String data = "This is the data in the output file";

        try {
            // Creates a FileWriter
            FileWriter file = new FileWriter("src/main/java/JavaReadWrite/output.txt");

            // Creates a BufferedWriter
            BufferedWriter output = new BufferedWriter(file);

            // Writes the string to the file
            output.write(data);

            // Flushes data to the destination
            output.flush();
            System.out.println("Data is flushed to the file.");

            // Closes the writer
            output.close();
        }

        catch (Exception e) {
            e.getStackTrace();
        }
    }
}
