package com.org.scala_basics

object ScalaEmptyVal {

  def main(args: Array[String]): Unit = {
    def usingnull(thing:Null):Unit = {
      println("GeeksForGeeks")
    }
    usingnull {null}


    def printNumber(num:(Int) => Unit):Unit ={
      num(1)
      num(2)
      num(3)
    }
    printNumber(println)
    println(Nil)

    val p:Option[String] = None
    println(p.getClass())


  }

}
