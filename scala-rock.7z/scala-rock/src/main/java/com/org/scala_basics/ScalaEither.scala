package com.org.scala_basics

object ScalaEither extends App {

  def Division(a:Int,b:Int):Either[String,Int]={
    if (a == 0) Left("Division is not possible")
    else Right(a/b)
  }
  println(Division(0,10))
  println(Division(20,10))
}
