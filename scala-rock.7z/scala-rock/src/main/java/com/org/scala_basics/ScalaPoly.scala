package com.org.scala_basics
class example{
  def func(vehicle:String,category:String): Unit ={
    println(s"vehicle name : $vehicle and category : $category")

  }
  def func(name:String,age:Int):Unit ={
    println(s"name : $name and age : $age")
  }

  def func(a:Int,b:Int):Unit ={
    val  sum = a + b
    println(s"a + b = $sum")
  }
}
object ScalaPoly {
  def main(args: Array[String]): Unit = {
    val c = new example
    c.func("Mercedes","Blue")
    c.func(5,5)
    c.func("Sumit",28)
  }
}
