package com.org.scala_basics

class Principal
class Teacher extends  Principal
class Student extends Teacher
class Parent

class School{

  //Declaration of lower bound

  def display[T >: Parent](t:T): Unit ={
    println(t)
  }
}

object ScalaLowerBound {

  def main(args: Array[String]): Unit = {

    val principal = new Principal
    val teacher = new Teacher
    val student = new Student
    val parent = new Parent
    val s = new School
    s.display(principal)
    s.display(teacher)
    s.display(student)
    s.display(parent)
  }

}
