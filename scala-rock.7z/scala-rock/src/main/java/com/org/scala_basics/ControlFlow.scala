package com.org.scala_basics
import scala.util.control._

object ControlFlow {

  def main(args:Array[String]):Unit ={
    //Taking a variable
    var value: Int = 20

    if (value == 20){
      printf(s"Value is $value")


    }
    else if (value == 25) {
      println(s"Value is $value")

    }
    else{
      println(s"No Match Found for $value")
    }

    //while loop
    while (value < 30){
      println(s"value is $value")
      value += 1
    }

    for (x <- 1 to value/2){
      println(s"x = $x")
    }

    for (x <- 1 until 10){
      print(s"x = $x ")
    }
    println("For loop in action")

    for (w <- 0 to 2; z <- 8 until 10){
      println("w = "+ w + "; z = " + z)

    }
    //for loop using list
    val rank: Int = 0
    val rankList = List(1,2,3,4,5,6,7,8,9,10)
    for(rank <- rankList){
      println(s"RankList =  $rank")
    }

    for(rank <-rankList if rank < 7; if rank > 2){
      println("Author rank = "+ rank)
    }
    val output = for(rank <-rankList if rank > 2; if rank < 6) yield rank
    for(out <- output) println(s" New Author rank is $out")

    val b = new Breaks


    b.breakable{
      for(a <- 1 to 10){

        if (a == 6){
          //terminate the loop at 6
          b.break
        }
        else println("a = " + a)
      }
    }

    var num1:Int = 0
    var num2:Int = 0
    val x:List[Int] = List(5,10,15)
    val y:List[Int] = List(20,25,30)
    val outloop = new Breaks
    val inloop = new Breaks

    outloop.breakable{

      for(num1 <- x){
        println("num 1 = " + num1)
        inloop.breakable{
          for(num2 <- y){
            println("num 2 = " + num2)

            if (num2 ==25){
              inloop.break
            }
          }
        }

        if (num1 == 10){
          outloop.break
        }
      }
    }

    def factoril(n:Int):Int = {

      if (n == 0) return 1
      else return n * factoril(n- 1)
    }
    println(factoril(5))



  }








}
