package com.org.scala_basics

object ScalaRepeatedParameter {
  def main(args: Array[String]): Unit = {

    println(add(1,2,3,4,5,6,7,8,9))
    println(Mul(1,2,3,4,5,6))
    println(Mul(Array(1,2,3,4,5,6):_*))
    println(show("GeeksforGeeks","Computer","Science", "Portal"))

  }

  def add(x:Int*):Int = {
    x.fold(0)(_+_)
  }

  def Mul(x:Int*):Int = {
    x.product
  }

  def show(x:String,y:Any*):String ={
    "%s is a %s".format(x,y.mkString("_"))
  }
}
