package com.org.scala_basics

import scala.annotation.tailrec

object ScalaRecursion {

  def main(args:Array[String]):Unit = {

    println(fact(3))
    println(gcd(12,18))
    println(factorial(1,5))
  }

  def fact(n:Int):Int = {
    if (n == 1) 1
    else n * fact(n-1)
  }
  @tailrec
  def gcd(a:Int,b:Int):Int = {
    if (b==0) a
    else gcd(b,a % b)
  }

  @tailrec
  def factorial(acc:Int,n:Int):Int ={
    if (n == 1) acc
    else factorial(n * acc,n-1)
  }

}
