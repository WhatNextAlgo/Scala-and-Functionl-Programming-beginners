package com.org.scala_basics

object ScalaAnonymous extends App{

  def func1 =  (str1:String,str2:String) => str1 + str2
  def func2 =(_:String) + (_:String)

  println(func1("Sumit","Maurya"))
  println(func2("He is ","Legend."))

  //A function which take anonymous function as a paramter

  def func3(fun:(String,String)=> String) ={
    fun("Dog","Cat")
  }

  println(func3((str1:String,str2:String)=> str1 + str2 ))
  println((func3(_ + " & "+_)))

}
