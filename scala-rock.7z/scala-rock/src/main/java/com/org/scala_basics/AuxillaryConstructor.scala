package com.org.scala_basics

class GFG1(name :String = "Sumit",age:Int = 0){
  var no:Int = 0

  def display():Unit ={
    println(s"name : $name and age : $age")
  }
  //auxillary constructor
  def this(name:String,age:Int,no:Int){
    this(name,age)
    this.no = no
  }

}

class Animal private(var name:String,var age:Int){
  def display():Unit= {
    println(s"name : $name and age : $age")
  }
}

object Animal{

  val animal = new Animal("Dog",10)
  def getDetails = animal
}

class Company{
  private var Cname: String  = ""
  private var Employee : String = ""
  def show():Unit = {
    println(s"Cname : $Cname and Employee : $Employee")
  }

  //Auxiliary Constructor

  def this(Cname:String){
    this()
    this.Cname = Cname
  }
  def this(Cname: String,Employee:String){
    //previous auxiliary constructor
    this(Cname)
    this.Employee = Employee
  }

}

class Monter(var name:String,var age:Int){

  def show():Unit ={
    println(s"name -> $name , age -> $age ")

  }
  def this(name :String){
    this(name,0)
  }
  def this(){
    this("Default",0)
  }
}


object AuxillaryConstructor {

  def main(args: Array[String]):Unit = {
    val gfg = new GFG1("name",28,20);
    gfg.display()

    val a= Animal.getDetails
    a.display()

    val c = new Company()
    c.show()

    val c1 = new Company("GEP")
    c1.show()

    val c2  = new Company("GEP","Sumit")
    c2.show()

    val m = new Monter("egleStorm",1000)
    m.show()

  }

}
