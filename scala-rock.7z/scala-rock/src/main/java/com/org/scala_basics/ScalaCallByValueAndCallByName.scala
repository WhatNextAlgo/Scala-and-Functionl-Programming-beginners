package com.org.scala_basics



object ScalaCallByValueAndCallByName {
  def main(args: Array[String]): Unit = {

    //call By value
    def ArticleCount(i:Int):Unit ={

      println("Tanya did article " +
        "on day one is 1 - Total = " + i)
      println("Tanya did article " +
        "on day two is 1 - Total = " + i)
      println("Tanya did article "+
        "on day three is 1 - Total = " + i)
      println("Tanya did article " +
        "on day four is 1 - Total = " + i)
    }
    var Total = 0
    ArticleCount{
      Total += 1; Total
    }
    //call by Name
    def ArticleCount1(i: =>Int):Unit ={

      println("Tanya did article " +
        "on day one is 1 - Total = " + i)
      println("Tanya did article " +
        "on day two is 1 - Total = " + i)
      println("Tanya did article "+
        "on day three is 1 - Total = " + i)
      println("Tanya did article " +
        "on day four is 1 - Total = " + i)
    }
    ArticleCount1{
      Total += 1; Total
    }

    def doSomething(x:Int):Int ={
      println("Calling Something")
      x //return value
    }

    def callByName(x: => Int):Unit={
      println("x1 = " + x)
      println("x2 = " + x)
    }
    var x = 0
    callByName(doSomething{
      x +=1;x
    })
  }
}
