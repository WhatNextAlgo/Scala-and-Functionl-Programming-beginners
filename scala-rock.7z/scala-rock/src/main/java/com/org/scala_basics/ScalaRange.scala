package com.org.scala_basics

object ScalaRange {

  def main(args:Array[String]):Unit ={

    var x = Range(0,10,1)
    println(x.last)

    var y = x.inclusive
    y.foreach(print)
    println()
    var z  = 0 to 10
    z.foreach(print)


  }
}

