package com.org.scala_basics

object PatternMatching {

  def main(args:Array[String]):Unit ={

    for(arg <- args){
      println(arg)
    }
    println(text(2))
    println((text2("C")))

  }

  def text(x: Int):String = x match {
    case 1 => "Hello, Geeks!!"
    case 2 => "Are you learning Scala?"
    case _ => "Good Luck!!"
  }

  def text2(x:String): String = x match {
    case "A" => "Apple"
    case "B" => "Banana"
    case "C" => "Carrot"
    case _ => "Not found"
  }

}
