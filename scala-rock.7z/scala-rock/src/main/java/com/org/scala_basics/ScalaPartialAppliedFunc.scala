package com.org.scala_basics

object ScalaPartialAppliedFunc {

  def main(args: Array[String]): Unit = {
    val m = Mul(20,_:Double)
    println(m(10))
    val r  = Mul _
    println(r(10.5,10.0))

    val x  = (Mul _).curried
    println(x(30)(30))
  }

  def Mul(a:Double,b:Double):Double ={
    a * b
  }

}
