package com.org.scala_basics

object ScalaCurrying extends App {

  def add(a:Int)=(b:Int) => a + b
  def addAndMuiltiplier(a:Int)= (b:Int) => (c:Int) => (a + b) * c

  println(add(10)(20))
  println(addAndMuiltiplier(10)(10)(3))
  def add2(a:Int)(b:Int)(c:Int) = (a + b) * c

  val sum = add2(10)(10)_
  println(sum(3))

}
