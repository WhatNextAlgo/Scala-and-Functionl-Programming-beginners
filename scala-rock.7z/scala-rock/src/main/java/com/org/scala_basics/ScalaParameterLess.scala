package com.org.scala_basics



object ScalaParameterLess {

  class NoParameter(name:String,age:Int){

    def author = println(name)
    def authorAge = println(age)

    def printInformation():Unit = {
      println(s"Author Name is $name and Age of Author is $age.")
    }

}

  def main(args:Array[String]):Unit = {
    val p = new NoParameter("Sumit",28)
    p.author
    p.authorAge
    p.printInformation()
  }

}

