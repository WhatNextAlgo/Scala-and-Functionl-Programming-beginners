package com.org.scala_basics

object ScalaNestedFunc {

  def main(args: Array[String]): Unit = {

    maxAndMin(10,7)

  }

  def maxAndMin(a:Int,b:Int):Unit = {

    def maxValue(a:Int,B:Int):Unit = {
      if (a > b) println("Max = " + a)
      else println("Max = " + b)
    }

    def minValue(a:Int,b:Int):Unit = {
      if (a < b) println("Min = " + a)
      else println("Min = " + b)
    }
    maxValue(a,b)
    minValue(a,b)
  }

}
