package com.org.scala_basics

class Geek{

  //Inner class
  class G1{
    var a:Int  =0
    def method():Unit ={
      for(a <- 1 to 3){
        println("Welcome to inner class")
      }
    }
  }

}

abstract  class myauther(var name:String,var topic:String){
  def details()

}
class GFG(name:String,topic:String) extends myauther(name,topic){
  def details(): Unit ={
    println("Auther Name : " + name)
    println("Auther topic : "+ topic)
  }

}

object ScalaClasses {

  def main(args:Array[String]):Unit ={
    val obj =  new Geek();
    var o =  new obj.G1();
    o.method()

    val gfg = new GFG("Sumit","Doesn't feel like it")
    gfg.details()
  }


}
