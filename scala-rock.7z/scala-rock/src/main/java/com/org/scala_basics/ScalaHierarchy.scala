package com.org.scala_basics

object ScalaHierarchy {

  def main(args:Array[String]):Unit ={
    val list : List[Any] = List(
      false,
      "abc",
      'c',
      5,
      19.5f,
      23.434d
    )
    list.foreach(x=> println(x.getClass()))

    val list2 :List[AnyVal] = List(
      false,
      //"abc", // string is not a type of AnyVal
      'c',
      5,
      19.5f,
      23.434d
    )
    list2.foreach(x=> println(x.getClass()))

    val list3:List[AnyRef] = List(
      "GFG",
      (1,2,4),
      List(1,2,4)
    )
    list3.foreach(x=> println(x.getClass()))
  }

}
