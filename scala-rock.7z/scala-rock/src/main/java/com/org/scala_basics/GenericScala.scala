package com.org.scala_basics

class GenericScala{
  var name: String = "Sumit"
  var age:Int = 28
  def display():Unit = {
    println("name : " + name + ",\nAge : " + age)
  }
}


object GenericScala {

  def main(args: Array[String]):Unit ={
    val c = new GenericScala()
    c.display()

    abstract class Divide[z]{
      def divide(u:z,v:z):z
    }
    class intDivide extends Divide[Int]{
      override def divide(u: Int, v: Int): Int = u/v
    }
    class doubleDivide extends Divide[Double]{
      override def divide(u: Double, v: Double): Double = u/v
    }

    val i = new intDivide().divide(10,5)
    val d = new doubleDivide().divide(20.0,10.0)
    println("i : " + i + ", d : " +d)
  }
}
