package com.org.scala_basics

object ScalaLambdaFunc {
  def main(args: Array[String]): Unit = {
    val func = (x:Int) => x * x

    val l1 = List(1,1,2,3,5,8)
    val l2 = List(13,21,34)
    val res1 = l1.map(func)
    val res2 = l2.map(func)

    println(res1)
    println(res2)

    def transform(x:Int,f:Int => Double):Double={
      f(x)
    }

    val res3  = transform(2,r => 3.14 * r)
    println(res3)

    def tranformList(l:List[Int] ,f:Int => Double):List[Double]={
      l.map(f)
    }

    val res4 = tranformList(List(1,2,3,4,5,6),r => 0.5 * r)
    print(res4)

  }

}
