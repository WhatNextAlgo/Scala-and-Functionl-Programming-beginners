package com.org.scala_basics

object ScalaHigherOrderFunc {

  def main(args: Array[String]): Unit = {

    def apply(y:Int,x:(Int) => String):String ={
      x(y)
    }

    def format[T](z:T) = s"{ ${z.toString()} }"

    println(apply(32,format))


    val list:List[Int] = List(3,6,9)

    def multiplyValue = (y:Int) => y * 3

    val result = list.map(y => multiplyValue(y))
    println(result)

  }

}
