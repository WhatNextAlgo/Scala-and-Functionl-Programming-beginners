package com.org.scala_basics

class GeeksforGeeks
class Author extends GeeksforGeeks
class Geeks extends Author

class  ComputerSciencePortal{

  def display[T<: Author](t:T): Unit ={
    println(t)
  }
}

object scalaUpperBound {

  def main(args: Array[String]): Unit = {

    val geeksforgeeks = new GeeksforGeeks
    val author = new Author
    val geeks = new Geeks

    val computerscienceportal = new ComputerSciencePortal

    //computerscienceportal.display(geeksforgeeks)
    computerscienceportal.display(geeks)
    computerscienceportal.display(author)
  }

}
