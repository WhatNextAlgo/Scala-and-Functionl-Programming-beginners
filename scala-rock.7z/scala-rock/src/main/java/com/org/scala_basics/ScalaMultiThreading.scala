package com.org.scala_basics

class myThread extends Thread{
  override def run(): Unit = {

    println(s"Thread ${Thread.currentThread().getName()} is running")
  }
}
class myRunnableThread extends Runnable{
  override def run(): Unit = {
    println(s"Runnable Thread ${Thread.currentThread().getName()} is running")

  }
}

object ScalaMultiThreading {
  def main(args: Array[String]): Unit = {

    for (x<- 1 to 5){
      var th = new myThread
      th.setName(x.toString())
      th.start()
    }

    for (x<- 1 to 5){
      var th = new Thread(new myRunnableThread())
      th.setName(x.toString())
      th.start()
    }

  }



}
