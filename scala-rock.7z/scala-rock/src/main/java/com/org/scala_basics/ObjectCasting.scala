package com.org.scala_basics

case class Casting(a:Char)

class Subject(name:String,article:Int){
  def canEqual(a:Any) = a.isInstanceOf[Subject]

  override def equals(that: Any): Boolean = {
    that match {
      case that: Subject => that.canEqual(this) && this.hashCode() == that.hashCode()
      case _ => false
    }
  }

  override def hashCode(): Int = {
    val prime = 31
    var result = 1
    result = prime * result + article
    result = prime * result + ( if (name == null) 0  else name.hashCode)
    result
  }
}
object ObjectCasting {
  def main(args: Array[String]): Unit = {
    val c  = 'c'

    val d  = c.asInstanceOf[Int]
    println(s"The value of c after casting into integer is $d")

    val g1 = new Subject("Scala",38)
    val g2 = new Subject("Scala",38)

    if (g1.hashCode() == g2.hashCode()){
      if (g1.equals(g2)) println("Both Objects are equal.")
      else println("Both Objects are not equal. ")
    }else{
      println("Both Objects are not equal. ");
    }




  }

}
