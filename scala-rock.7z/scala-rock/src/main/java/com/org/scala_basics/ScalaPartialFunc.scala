package com.org.scala_basics

object ScalaPartialFunc {

  def main(args: Array[String]): Unit = {

    val r = new PartialFunction[Int,Int] {
      override def isDefinedAt(x: Int): Boolean = x != 0

      override def apply(v1: Int): Int = v1 * 3
    }
    println(r(10))

    val M:PartialFunction[Int,Int]={

      case x if (x % 5) == 0 => x * 5
    }
    val m :PartialFunction[Int,Int]={
      case y if (y % 2) == 0 => y * 2
    }
    val v = M orElse m
    println(v(5))
    println(v(4))

    // Applying collect method
    val l = List(7,15,9) collect M
    println(l)

  }



}
