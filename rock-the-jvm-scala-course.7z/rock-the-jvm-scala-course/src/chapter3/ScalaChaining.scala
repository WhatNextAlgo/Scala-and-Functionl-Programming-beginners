package chapter3

class PersonInfo {
  protected var fname = ""
  protected var lname = ""
  def setFirstName(firstName:String):this.type = {
    fname = firstName
    this
  }
  def setLastName(lastName:String):this.type = {
    lname = lastName
    this
  }
}
class Employee extends PersonInfo {
  protected var role = ""

  def setRole(role:String):this.type = {
    this.role = role
    this
  }

  override def toString: String =  "Name : %s %s\nDesignation: %s".format(fname, lname, role)
}
object Chaining extends App{
val e = new Employee
  e.setFirstName("Sumit").setLastName("Maurya").setRole("Senior Data Engineer")
  println(e)
}
