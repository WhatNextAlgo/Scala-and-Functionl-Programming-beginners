package chapter3

object scalaTrait extends App{
  def printAll(strings:Any*){
    strings.foreach(println)
    println(strings.getClass)
  }
  val fruits = List("apple", "banana", "cherry",1,2,3,(4,5,6),List("1","3"))
  printAll(fruits:_*)
  printAll("Foo")
val c = new Child
  println(c.printSuper)
  println(c.printMother)
  println(c.printFather)
  println(c.printHuman)

}
trait Human {
  def hello = "The Human trait"
}
trait Mother extends Human{
  override def hello: String = "Mother"
}
trait Father extends Human{
  override def hello: String = "Father"
}

class Child extends Human with Mother with Father{
  def printSuper = super.hello
  def printMother = super[Mother].hello
  def printFather = super[Father].hello
  def printHuman = super[Human].hello
}

