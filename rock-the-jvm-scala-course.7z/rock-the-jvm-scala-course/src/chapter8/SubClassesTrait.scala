package chapter8

import sun.security.util.Password

object SubClassesTrait extends App {
val e  = new Enterprise
  val e1 = new Enterprise1
  println(e1.ejectWarpCore("password"))
  e1.startWarpCore
}
//How to define a Scala trait so it can only be subclassed by a certain type
class Starship
trait WarpCoreEjector
trait FireExtinguisher
trait StarFleetWarpCore{
  this:Starship with WarpCoreEjector with FireExtinguisher  => {println("hello world")}
}

class Enterprise extends Starship with StarFleetWarpCore with WarpCoreEjector with FireExtinguisher

//How to declare that a Scala trait can only be mixed into a type that has a specific method
class Starship1
trait WarpCore{
  this: {def ejectWarpCore(password: String):Boolean
    def startWarpCore: Unit
  } =>
}

class Enterprise1 extends Starship with WarpCore{
  def ejectWarpCore(password: String):Boolean = {
  if (password == "password"){
    println("ejectWarp core")
    true
  }else{
    false
  }

  }
  def startWarpCore = println("Multiple method in trait")

}

