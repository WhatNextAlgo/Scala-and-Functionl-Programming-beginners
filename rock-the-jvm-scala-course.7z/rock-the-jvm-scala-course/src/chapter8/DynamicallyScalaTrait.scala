package chapter8

object DynamicallyScalaTrait extends App{

  val d =  new DavidBanner with Angry

}
//How to dynamically add a Scala trait to an object instance

class DavidBanner

trait Angry {
  println("Yo won't like me ...")
}