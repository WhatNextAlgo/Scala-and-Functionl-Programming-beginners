package chapter8

object ScalaTraits extends App {
  val zeus = new Dogs("Zeus")
  zeus.ownerIsHome
  zeus.jumpForJoy
}

//How to use abstract and concrete fields in Scala traits

trait PizzaTrait{
  var numToppings : Int // abstract
  var size: Int = 14 // concrete
  val maxNumToppings = 10 // concrete
}

class Pizza extends PizzaTrait{
  var numToppings = 10 // 'override' not needed
  size = 25 // 'var' and 'override' not needed
  override val maxNumToppings = 20
}

//How to use a Scala trait like an abstract class
trait Pet{
  def speak {println("Yo")} //concrete implementation
  def comeToMaster          // abstract
}
class Dog extends Pet {
  // don't need to implement 'speak' if you don't need to
  override def comeToMaster: Unit = println("I'm coming")
}
class Cat extends Pet {
  // override the speak method
  override def speak { ("meow") }
  def comeToMaster { ("That's not gonna happen.") }
}

//How to use Scala traits as simple mixins
trait Tail{
  def wagTail = println("tail is wagging") // concrete implementation
  def stopTail = println("tail is stopped") // concrete implementation
}
abstract class Pets(var name:String){
  def speak //abstract
  def ownerIsHome = println("excited")
  def jumpForJoy = println("jumping for joy")
}

class Dogs(name:String) extends Pets(name) with Tail{
  override def speak: Unit = println("woof")

  override def ownerIsHome: Unit = {
    wagTail
    speak
  }

}