package chapter9

import chapter9.otherscope
import chapter9.otherscope.Foo

import javax.sql.rowset.spi.SyncResolver

object FunctionLiteral extends App{
  //You want to use an anonymous function in Scala — also known as a function literal
  // — so you can pass it into a method that takes a function, or to assign it to a variable.
  val x =  List.range(1,10)
  println(x)
  //filter only even no.
  val evens = x.filter((i:Int) => i % 2 == 0)
  println(evens)
  //filter using wildcard
  val odds = x.filter(_ % 2 != 0)
  println(odds)

  //How to use functions as variables (values) in Scala

  val double = (i:Int) => {i * 2}
  println(double(2))
 //implicitly determine the return type
  val f = (i:Int) => {i % 2 == 0}
  println(f(2))

  //explicitly define the return type
  // <var> : <type> => <returnType> = (instance variable) => expression
  val f1 :(Int) => Boolean = (i) => {i % 2 != 0 }
  println(f1(3))

  println(x.filter(f1))

  //How to define a Scala method that accepts a function parameter
  //def <funcName>(<callbackFuncName>:(<parameter>) => <returnType>):<returnType> ={}
  def executeFunction(callBack:()=>Unit): Unit ={
    callBack()
  }
  def sayHello = () => {println("Hello callBack Function")}

  executeFunction(sayHello)

  //How to define Scala methods that take complex functions as parameters (syntax)

  def executeTimes(callBack:() => Unit,numTimes:Int): Unit = {
    for (x <- 1 to numTimes) callBack()
  }

  executeTimes(sayHello,5)

  def executeAndPrint(f:(Int,Int)=>Int,x:Int,y:Int): Unit ={
    val result = f(x,y)
    println(result)

  }
  val sum = (x:Int,y:Int) =>  x + y
  val multiple = (x:Int,y:Int) =>  x * y

  executeAndPrint(sum,1,1)
  executeAndPrint(multiple,5,5)
  //signature of complex function
  //1 - define the method
  def exec(callback:(Any,Any)=>Any,x:Any,y:Any):Any = {
    callback(x,y)
  }
  // 2 - define a function to pass in
  val printTwoThing = (a:Any,b:Any) =>{
     println(a)
     println(b)

  }
  // 3 - pass the function and some parameters to the method
  case class Student(name:String)
  exec(printTwoThing,"hello",Student("Sumit"))

  var hello1 = "Sumit"
  def sayHello1(name: String) { println(s"$hello1, $name") }
val f2  =  new Foo
  f2.exec(sayHello1,"Maurya")
  hello1 = "Rahul"
  f2.exec(sayHello1,"Pal")


  //second example
  import scala.collection.mutable.ArrayBuffer
  //step 1
  val fruit =  ArrayBuffer("Apple")
 //step 2
  val addToBasket = (s:String) =>{
    fruit += s
    println(fruit.mkString(", "))
  }
  //step 3
  def buyStuff(f:String =>Unit,item:String): Unit ={
    f(item)
  }

  buyStuff(addToBasket,"mango")
  buyStuff(addToBasket,"banana")

  //How to use partially applied functions in Scala
  val sumOfInt = (a:Int,b:Int,c:Int) => a + b + c
  val f3 = sumOfInt(1,2, _:Int)
  println(f3(3))

  def warp(prefix:String,html:String,suffix:String) = {
    prefix + html + suffix
  }

  val wrapWithDiv = warp("<div>",_:String,"</div>")
  println(wrapWithDiv("<img src=\"/images/foo.png\" />"))

  //How to create a method that returns a function in Scala
  //anonymous method signature
  //(s: String) => { prefix + " " + s }

  def saySomething(prefix:String) = (s:String) =>{
    prefix + " " + s
  }

  val sayHi = saySomething("Hi")
  println(sayHi("Sumit"))

  //Another example

  def greeting(language:String) = (name:String) =>{
    language match {
      case "english" => "Hello " + name
      case "spanish" => "Hello " + name
    }
  }

  val hello = greeting("english")
  println(hello("I' m learning english"))

  val helloSpanish = greeting("spanish")
  println(helloSpanish("I' m learning spanish"))

  //How to create and use partial functions in Scala

  val convert1to5 = new PartialFunction[Int,String] {
    val numbs: Array[String] = Array("one","two","three","four","five")
    override def apply(i:Int) = numbs(i-1)

    override def isDefinedAt(x: Int): Boolean = x > 0 && x < 6
  }

  val convert6to10 = new PartialFunction[Int,String] {
    val numbs: Array[String] = Array("six","seven","eight","nine","ten")
    override def apply(i:Int) = numbs(i-1)

    override def isDefinedAt(x: Int): Boolean = x > 5 && x < 11
  }

  val handle1to10 = convert1to5 orElse  convert6to10

  println(handle1to10(3))
  println(handle1to10.isDefinedAt(11))

  //divide
  val divide: PartialFunction[Int,Int] = {
    case d : Int if d != 0 => 42/ d
  }
  println(List(42,2) collect  { divide })

  println(List(42, "cat") collect { case i: Int => i + 1 })

  val sample = 1 to 5

  val isEven: PartialFunction[Int, String] = {
      case x if x % 2 == 0 => x + " is even"
    }
  val evenNumbers = sample collect isEven
  println(evenNumbers)







}
