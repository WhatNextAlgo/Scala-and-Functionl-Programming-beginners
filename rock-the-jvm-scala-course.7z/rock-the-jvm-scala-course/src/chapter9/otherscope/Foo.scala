package chapter9.otherscope

class Foo {
  def exec(f:(String) => Unit, name: String) {
    f(name)
  }
}
