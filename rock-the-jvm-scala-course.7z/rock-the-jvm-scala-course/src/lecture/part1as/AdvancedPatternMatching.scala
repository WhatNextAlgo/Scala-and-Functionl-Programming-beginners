package lecture.part1as

import java.awt.image.WritableRaster

object AdvancedPatternMatching extends App{
  val numbers = List(1)
  val description = numbers match {
    case head::Nil => println(s"the only elements is $head")
    case _ => println("No found")
  }
  //create a pattern Matching
  class Person(val name:String,val age:Int)
  object Person{
    def unapply(person:Person):Option[(String,Int)] = Some((person.name,person.age))

    def unapply(age: Int):Option[String] =Some(if (age < 21) "miner" else "major")
  }
  val bob = new Person("Bob",25)
  val greeting = bob match {
    case Person(n,a) => println(s"Hi, my name is $n and I am $a years old.")
  }
  greeting
  val legalStatus = bob.age match {
    case Person(status) => println(s"My legal status is $status")
  }
  legalStatus

  //exercise
  object singleDigit{
    def unapply(arg: Int): Boolean = arg > - 10 && arg < 10
  }
  object even{
    def unapply(arg: Int):Boolean = arg % 2==0
  }
  val n:Int = 9
  val mathProperty = n match {
    case singleDigit() => "single digit"
    case even() => "an even number"
    case _=> "no property"
  }
  println(mathProperty)

  //infix pattern
  case class Or[A,B](a:A,b:B)
  val either = Or(2,"two")
  val humanDescription = either match {
    case number Or string => s"$number is written as $string"
  }
  println(humanDescription)

  //decomposing sequences

  val varang = numbers match {
    case List(1,_*) => "starting with 1"
  }

  abstract class MyList[+A]{
    def head:A = ???
    def tail:MyList[A] = ???

  }
  case object Empty extends MyList[Nothing]
  case class Cons[+A](override val head:A,override val tail:MyList[A]) extends MyList[A]

  object MyList{
    def unapplySeq[A](list:MyList[A]):Option[Seq[A]] = {
      if (list == Empty) Some(Seq.empty)
      else unapplySeq(list.tail).map(list.head +: _)
    }
  }

  val myList :MyList[Int] = Cons(1,Cons(2,Cons(3,Empty)))
  val decompose = myList match {
    case MyList(1,2,_*)=>"Starting 1,2"
    case _=>"Someting else"
  }
  println(decompose)

  //custom return types for unapply instead of Option Some()
  //isEmpty:Boolean, get:something
  abstract class Wrapper[T]{
    def isEmpty:Boolean
    def get:T
  }
  object PersonWrapper {
    def unapply(person: Person):Wrapper[String] = new Wrapper[String] {
      override def isEmpty: Boolean = false

      override def get: String = person.name
    }
  }
  println(bob match {
    case PersonWrapper(n)=>s"This person's name is $n"
  })



}
