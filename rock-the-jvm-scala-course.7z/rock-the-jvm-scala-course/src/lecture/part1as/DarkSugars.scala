package lecture.part1as

object DarkSugars extends App{
  //Syntax sugar #1 : methods with single param
  def singleArgMethod(args:Int):String = s"$args little ducks.."

  val description = singleArgMethod{
    //write some code
    46
  }
  List(1,2,3).map{
    x=> x + 1
  }
  //syntax sugar #2: single abstract method
  trait Action{
    def action(x:Int):Int
  }
  val anInstance: Action = new Action {
    override def action(x: Int): Int = x + 1
  }
  val aFunkyInstance: Action = (x:Int) => x + 1

  val aThread: Thread = new Thread(new Runnable {
    override def run(): Unit = println("hello, sugar")
  })

  val aSweeterThread:Thread = new Thread(()=>println("Hello, Sweet sugar"))

  abstract class AnAbstractType{
    def implemented:Int = 23
    def f(a:Int):Unit
  }
  val anAbstractInstance:AnAbstractType = (a:Int) => println("sweet")

  //syntax sugar #3: the :: and #:: method special
  val prependList = 2 :: List(3,4)
  //2.::(List(3,4)
  //List(3,4).::(2)

  //scala spec: last char decides associativity of method
  1:: 2:: 3::4::List(5,6)
  //List(5,6).::(4).::(3).::(2).::(1)

  class Mystream[T]{
    def -->:(value:T):Mystream[T] =this //actual implementation here

  }
  val myStream = 1-->:2-->:3-->:new Mystream[Int]

  //syntax sugar #4: multi-word method naming

  class TeenGirl(name:String){
    def `and then said`(gossip:String) = println(s"$name said $gossip")
  }
  val lilly = new TeenGirl("lilly")
  lilly `and then said` "Scala is so sweet"

  //syntax sugar #5: infix types
  class Composite[A,B]
  val composite:Int Composite String = ???

  class -->[A,B]
  val towards : Int --> String = ???

  //syntax sugar #6: update method is very special, much like apply
  val anArray = Array(1,2,4)
  anArray(2) = 7 //rewritten to anArray.update(2,7)
  //use in mutable collection

  //syntax sugar #7: setters for mutable container
  class Mutable{
    private var internalMember:Int = 0
    def member:Int =internalMember
    def member_=(value:Int) = {
      internalMember = value //setters
    }
  }
  val aMutableContainer = new Mutable
  aMutableContainer.member = 42 //rewritten aMutableContainer.member_=(42)
}
