package chapter2

object ScalaConstructor2 extends App{
  val teresa = new Employee("Teresa",Address1("Louisville", "KY"),25)
  println(teresa.name)
  println(teresa.address)
  println(teresa.age)


  val dog = new Dog("Fido")
  val cat = new Cat("Morris")
  dog.sayHello
  cat.sayHello
  println(dog)
  println(cat)
  // verify that the age can be changed
  cat.age = 10
  println(cat)
}
class Person1(var name:String,var address:Address1){
  // no way for Employee auxiliary constructors to call this constructor
  def this(name:String){
    this(name,null)
    address = null
  }
  override def toString: String = if (address == null) name else s"$name @ $address"
}

class Employee(name:String,address: Address1,var age:Int) extends Person1(name,address) {

  def this(name:String){
    this(name,null,0)
  }
  def this(name:String,address:Address1){
    this(name,address,0)
  }
  def this(age:Int){
    this("",null,age)
  }


}
case class Address1(city:String,state:String)

//abstract class
abstract class Pet(name:String){
  def greeting:String
  var age:Int
  def sayHello {println(greeting)}
  override def toString: String = s"I say $greeting, and I'm $age"
}
class Dog (name: String) extends Pet (name) {
  val greeting = "Woof"
  var age = 2
}
class Cat (name: String) extends Pet (name) {
  val greeting = "Meow"
  var age = 5
}