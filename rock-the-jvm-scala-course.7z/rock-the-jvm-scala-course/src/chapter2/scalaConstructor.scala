package chapter2

object scalaConstructor extends App{
  val p:Person = new Person("Sumit","maurya")
  val p1:Pizza = new Pizza(Pizza.DEFAULT_CRUST_SIZE,Pizza.DEFAULT_CRUST_TYPE)
  val p2:Pizza = new Pizza(Pizza.DEFAULT_CRUST_SIZE)
  val p3:Pizza = new Pizza(Pizza.DEFAULT_CRUST_TYPE)
  println(p1)
  println(p2)
  println(p3)

  val b =  Brain.getInstance
  println(b)

  val o =  new Order("Sumit")
  println(o.name)
  o.name = "Rahul"
  print(o.name)

  val per = PersonDetails("alvinalexander", "secret")
  per.address = Some(Address("Talkeetna", "AK", "99676"))
  per.address.foreach { a =>
    println(a.city)
    println(a.state)
    println(a.zip)
  }


}
class Person(private var firstName:String,var lastName:String){
  println("the constructor begin")
    //class field
  private val Home = System.getProperty("user.home")
  var age:Int = 27

  //class method
  override def toString: String = s"$firstName $lastName is $age years old."
  def printHome {println(s"Home = ${Home}")}
  def printFullName {println (s"${this}")} //uses toString
  printHome
  printFullName
  println("still in the constructor")


}
//primary constructor
class Pizza(var crustSize:Int,var crustType:String){
  //one-arg auxillary constructor
  def this(crustSize:Int){
    this(crustSize,Pizza.DEFAULT_CRUST_TYPE)
  }
  //one-arg auxillary constructor
  def this(crustType:String){
    this(Pizza.DEFAULT_CRUST_SIZE,crustType)
  }
  //zero-arg auxillary constructor
  def this(){
    this(Pizza.DEFAULT_CRUST_SIZE,Pizza.DEFAULT_CRUST_TYPE)
  }
  override def toString = s"A $crustSize inch pizza with a $crustType crust"
}
object Pizza{
  val DEFAULT_CRUST_SIZE = 12
  val DEFAULT_CRUST_TYPE = "THIN"
}
//How to define a private primary class constructor
class Brain private {
  override def toString: String = "This is the brain"
}
object Brain {
  val brain  = new Brain
  def getInstance = brain
}
//How to override default accessors and mutators in Scala classes

class Order(private var _name: String){
  def name = _name
  def name_=(aName:String) = _name = aName


}
//How to set uninitialized var fields (field types) in Scala
case class PersonDetails(var username:String,var password:String){
  var age = 0
  var firstName = ""
  var lastName = ""
  var address = None:Option[Address]
}
case class Address(var city:String,var state:String,var zip:String)


