package chapter6

object ScalaFactory extends App{
  val bmw = Cars("BMW")
  bmw.speak
  val mercedes = Cars("Mercedes")
  mercedes.speak
}

trait Cars{
  def speak
}

object Cars {
  private class BMW extends Cars{
    override def speak: Unit = println("I'm a BMW car")
  }
  private class Mercedes extends Cars{
    override def speak: Unit = println("I'm a Mercedes car")
  }
  def apply(t:String):Cars ={
    if (t == "BMW") new  BMW
    else new Mercedes
  }
}
