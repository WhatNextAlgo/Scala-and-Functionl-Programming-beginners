package chapter6
import chapter6.model._

import scala.collection.convert.StreamExtensions.StreamUnboxer
object MainDriver extends App {
  // access our method, constant, and enumeration
  echo("Hello, world")
  echo(MAGIC_NUM)
  echo(Margin.LEFT)


  // use our MutableMap type (scala.collection.mutable.Map)
  val mm = MutableMap("name" -> "Al")
  mm += ("password" -> "123")
  for ((k,v) <- mm) printf("key: %s, value: %s\n", k, v)
  val a =Array(Student("Sumit"),Student("Rahul"))
  println()

}

//How to create Scala object instances without using the “new” keyword (apply)

class Student{
  var name:String = ""
}
object Student{
  def apply(name:String):Student ={
    var s = new Student
    s.name = name
    s
  }
}

class Person {
  var name = ""
  var age = 0
}

object Person {

  // a one-arg constructor
  def apply(name: String): Person = {
    var p = new Person
    p.name = name
    p
  }

  // a two-arg constructor
  def apply(name: String, age: Int): Person = {
    var p = new Person
    p.name = name
    p.age = age
    p
  }

}