package chapter6

object ObjectCasting extends App{
  val a:Int = 10
  val b:Long = a.asInstanceOf[Long]
  val c:Byte = a.asInstanceOf[Byte]
  println(a)
  println(b)
  println(c)

  val animal = Animal.getAnimal("dog")
  println("animal: " + animal.getClass)                   // class chapter6.Dog
  println("animal: " + animal.getClass.getName)           // chapter6.Dog
  println("animal: " + animal.getClass.getSimpleName)     // Dog
  println("animal: " + animal.getClass.getCanonicalName)  // chapter6.Dog


}
sealed trait Animal
class Dog extends Animal
class Cat extends Animal
object Animal {
  // factory method
  def getAnimal(s: String): Animal = if (s == "dog") new Dog else new Cat
}
