package chapter1

object LoopPart1 extends  App{
  //How to loop over a collection with ‘for’ and ‘foreach’ (plus for loop translation)

  val a = Array("apple","banana","orange")
  for (e <- a) println(e.toUpperCase())
  //Returning values from a for-loop
  val newArray = for(e <- a) yield e.toUpperCase

  //for-loop counters
  for (i <- 0 until a.length)
    //println(s"index : $i , value : ${a(i)}")

  //zipWithIndex
  for ((e,count) <- a.zipWithIndex) //println(s"index : $count, value : ${e}")

  for (i <- 1 to 10 if i < 4) println(i)

  val names = Map("fname"->"Robert","lname"->"Goren")
  for((k,v) <- names) println(s"key: $k, value: $v")
  a.foreach(e => println(e.toUpperCase))
   //1 to 10 foreach println

  //How to use Scala ‘for’ loops (expressions) with multiple counters (multi-dimensional arrays)

  for (i <- 1 to 2 ; j <- 1 to 2) println(s"i = $i, j = $j")

  val array =  Array.ofDim[Int](2,2)
  array(0)(0)= 0
  array(0)(1)= 1
  array(1)(0)= 2
  array(1)(1)= 3

  for (i <- 0 to 1 ; j <- 0 to 1) //println(s"array($i)($j) = ${array(i)(j)}")

  //How to use a Scala `for` loop with embedded `if` statements (guards)
  //print all even number
  for{i<- 1 to 10 if i > 3  if i < 6 if i % 2 ==0 } print(s"$i ")

  //How to create a Scala “for comprehension” (for/yield loop)
  val names1 = Array("chris", "ed", "maurice")
  val capNames = for (e <- names1) yield e.toString().capitalize
  //println(capNames.mkString(" , "))

  var fruits = scala.collection.mutable.ArrayBuffer[String]()
  fruits += "apple"
  fruits += "banana"
  fruits += "orange"
  val out = for (e <- fruits) yield e.toUpperCase
  //println(out.mkString(" , "))

  //Scala: How to use break and continue in for and while loops
  import util.control.Breaks._
  println("===Break Example===")
  breakable{
    for (i <- 1 to 10 ) {
      if (i > 4) break
      println(s"$i")
    }
  }
  val searchMe = "peter piper picked a peck of pickled peppers"
  var  numPs:Int = 0
  for(i <- 0 until searchMe.length){
    breakable {
      if (searchMe.charAt(i) != 'p'){
        break
      }
      else{
        numPs += 1
      }
    }
  }
  println("Found " + numPs + " p's in the string.")
 import scala.util.control._
  val Inner = new Breaks
  val Outer = new Breaks
  Outer.breakable {
    for (i <- 1 to 5) {
      Inner.breakable {
        for (j <- 'a' to 'e') {
          if (i == 1 && j == 'c') Inner.break else println(s"i: $i, j: $j")
          if (i == 2 && j == 'b') Outer.break
        }
      }
    }
  }
  def sumToMax(arr: Array[Int], limit: Int): Int = {
    var sum = 0
    for (i <- arr) {
      sum += i
      if (sum > limit) return limit
    }
    sum
  }
  val a1 = Array.range(0,10)
  println(sumToMax(a1,10))

  import scala.annotation.tailrec
  /*
  factorialAcc(3 * acc,2) = 3 * 2 = 6
  factorialAcc(2 * acc,1) = 2 * 1 = 2
   */

  def factorial(n: Int): Int = {
    @tailrec def factorialAcc(acc: Int, n: Int): Int = {
      if (n <= 1) acc
      else factorialAcc(n * acc, n - 1)
    }
    factorialAcc(1, n)

  }

  //How to use a Scala if/then statement like a ternary operator
  val i:Int = 0
  println(if (i == 0) "a" else "b")

  //How to use a Scala match expression like a switch statement
  val num = i match {
    case 0 => println("0 received")
    case 1 => println("1 is good, too")
  }
  num

  val monthNumberToName = Map (
    1  -> "January",
    2  -> "February",
    3  -> "March",
    4  -> "April",
    5  -> "May",
    6  -> "June",
    7  -> "July",
    8  -> "August",
    9  -> "September",
    10 -> "October",
    11 -> "November",
    12 -> "December"
  )
  println(monthNumberToName(4))
  //Scala: How to match multiple conditions (patterns) with one case statement
  i match {
    case 1 | 3 | 5 => println("old number")
    case 2 | 4 | 6 => println("even number")
    case _ => println("UnKnown")
  }
  val cmd = "stop"
  cmd match {
    case "start" | "go" => println("starting")
    case "stop" | "quit" | "exit" => println("stopping")
    case _ => println("doing nothing")
  }
  //Scala: How to assign the result of a match expression to a variable
  def isTrue(a:Any) = a match{
    case 0 | "" => false
    case _ => true
  }
  println(isTrue(1))
  //How to use pattern matching in Scala match/case expressions

}
