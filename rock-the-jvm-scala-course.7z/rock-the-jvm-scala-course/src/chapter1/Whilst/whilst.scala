package chapter1.Whilst
import scala.annotation.tailrec
object whilst extends App{
  @tailrec
  def whilst(testCondition: => Boolean)(codeBlock: => Unit): Unit ={
    if (testCondition) {
      codeBlock
      whilst(testCondition)(codeBlock)
    }

  }

  def doubleIf(test1: => Boolean)(test2: => Boolean)(codeBlock1: => Unit):Unit={
    if (test1 && test2) {
      codeBlock1
    }
  }

}
