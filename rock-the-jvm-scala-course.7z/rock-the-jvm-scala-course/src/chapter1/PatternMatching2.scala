package chapter1

trait Animal
case class Dog(name:String) extends Animal
case class Cat(name:String) extends Animal
case object Woodpecker extends Animal
object PatternMatching2 extends App{

  def determineType(x:Any):String = x match {
    case Dog(dog) => s"Got a Dog, name is $dog"
    case _:Cat => "Got a Cat (ignoring the name)"
    case Woodpecker => "Got a Woodpecker"
    case _=> "Unknown"
  }
    println(determineType(new Dog("Rocky")))
    println(determineType(new Cat("Rusty the Cat")))
    println(determineType(Woodpecker))

  //How to add ‘if’ expressions (guards) to match/case expressions
  10 match {
    case a if 0 to 9 contains a => println("0-9 range: " + a)
    case b if 10 to 19 contains b => println("10-19 range: " + b)
    case c if 20 to 29 contains c => println("20-29 range: " + c)
    case _ => println("Hmmm...")
  }
  1 match {
    case x if x == 1 => println("one, a lonely number")
    case x if (x == 2 || x == 3) => println(x)
    case _ => println("some other value")
  }
  class Stock(val symbol: String,val price:Int)
  new Stock("XYZ",19) match {
    case x if (x.symbol == "XYZ" && x.price < 20) => println(s"buy the stock")
    case x if (x.symbol == "XYZ" && x.price > 50) => println("sell the stock")
    case _ => // do nothing
  }
  case class Person(name:String)
  def speak(p: Person) = p match {
    case Person(name) if name == "Fred" => println("Yubba dubba doo")
    case Person(name) if name == "Bam Bam" => println("Bam bam!")
    case _ => println("Watch the Flintstones!")
  }
  speak(Person("Fred"))

  //How to use Lists in Scala match expressions
  def listOfString(list:List[String]):String = list match {
    case s :: rest =>s + " " + listOfString(rest)
    case Nil => "End"
  }
  val fruits = "Apples" :: "Bananas" :: "Oranges" :: Nil
  println(listOfString(fruits))
  def sum(list: List[Int]): Int = list match {
    case Nil => 0
    case n :: rest => n + sum(rest)
  }

  def multiply(list: List[Int]): Int = list match {
    case Nil => 1
    case n :: rest => n * multiply(rest)
  }
  val nums = List(1,2,3,4,5)
  println(sum(nums))
  println(multiply(nums))
}
