package playground

object ScalaPlayground extends App {
  println("Hello, scala")

}
