from pyspark.sql import SparkSession

spark = SparkSession.builder\
.master("local")\
.config("spark.jars", r"C:\Users\Sumit.Maurya\Downloads\connector\mysql-connector-java-8.0.26.jar")\
.config("spark.executor.extraClassPath", r"C:\Users\Sumit.Maurya\Downloads\connector\mysql-connector-java-8.0.26.jar")\
.config("spark.executor.extraLibrary", r"C:\Users\Sumit.Maurya\Downloads\connector\mysql-connector-java-8.0.26.jar")\
.config("spark.driver.extraClassPath", r"C:\Users\Sumit.Maurya\Downloads\connector\mysql-connector-java-8.0.26.jar")\
.appName("PySpark_MySQL_test")\
.enableHiveSupport()\
.getOrCreate()

"""
spark = SparkSession\
    .builder\
    .appName("Read Data from MySQL")\
    .enableHiveSupport()\
    .getOrCreate()
"""
spark.sparkContext.setLogLevel("ERROR")

order_df = spark.read.format("jdbc")\
    .option("url", "jdbc:mysql://localhost:3306/sql_store") \
    .option("driver", "com.mysql.jdbc.Driver")\
    .option("dbtable", "customers") \
    .option("user", "root")\
    .option("password", "S$8080434231t")\
    .load()

order_df.show(10)

"""
spark-submit --master local[*] --jars C:/Users/Sumit.Maurya/Downloads/connector/mysql-connector-java-8.0.26.jar C:/Users/Sumit.Maurya/IdeaProjects/pyspark_project/my_module/mysql_data.py
"""

"""
spark-submit --master local[*] --jars "C:\\Users\\Sumit.Maurya\\Downloads\\connector\\mysql-connector-java-8.0.26.jar" "C:\\Users\\Sumit.Maurya\\IdeaProjects\\pyspark_project\\my_module\\mysql_data.py"
"""