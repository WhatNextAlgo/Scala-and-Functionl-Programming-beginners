from pyspark.sql import SparkSession

spark = SparkSession.builder\
        .appName("Python_From_Intellij")\
        .master("local").getOrCreate()

df_col = spark.read.format("csv")\
        .option("inferSchema", True)\
        .option("header", True)\
        .load("entities.csv")\
        .columns

print(df_col)