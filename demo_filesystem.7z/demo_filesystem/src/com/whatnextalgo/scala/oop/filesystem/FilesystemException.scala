package com.whatnextalgo.scala.oop.filesystem

class FilesystemException(message:String) extends RuntimeException(message){


}
