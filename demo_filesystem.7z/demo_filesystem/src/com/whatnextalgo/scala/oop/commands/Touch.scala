package com.whatnextalgo.scala.oop.commands
import com.whatnextalgo.scala.oop.files.{DirEntry, File}
import com.whatnextalgo.scala.oop.filesystem.State

class Touch (name:String) extends CreateEntry(name) {
  override def createSpecificEntry(state: State): DirEntry =
    File.empty(state.wd.path,name)

}
