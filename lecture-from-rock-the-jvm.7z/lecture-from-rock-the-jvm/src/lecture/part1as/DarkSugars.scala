package lecture.part1as

import scala.util.Try

object DarkSugars extends App {

  //syntax sugar #1: methods with single parameter

  def singleArgMethod(arg:Int):String = s"$arg little ducks..."

  val description  = singleArgMethod{
    //write some complex code
    42
  }
  val aTryInstance = Try{ //java's try {...}
    throw new RuntimeException
  }
  List(1,2,3).map { x =>
      x + 1
  }
  // syntax sugar #2: Single abstract method
  trait Action{
    def act(x:Int):Int
  }

  val anInstance:Action = new Action {
    override def act(x: Int): Int = x + 1

  }
  val aFunkyInstance:Action = (x:Int) => x + 1 //magic

  // example: Runnable
  val aThread =  new Thread(new Runnable {
    override def run(): Unit = println("Hello, Scala")
  })

  val aSweeterThread =  new Thread(()=> println("Sweet, Scala!"))

  abstract class AnAbstractType{
    def implemented :Int  = 23
    def f(x:Int):Unit
  }

  val anAbstractInstance: AnAbstractType =(a:Int) => println("sweet")

  // syntax sugar #3 : the :: methods are special
  val prependList = 2 :: List(3,4)
  // 2.::(List(3,4))
  //List(3,4).::(2)
  //?!
  // scala spec: Last char decides associativity of method
  1 :: 2 ::3 :: List(4,5)
  List(4,5).::(3).::(2).::(1) //equivalent

  class MyStream[T] {
    def -->:(value:T):MyStream[T] = this //actual Implementation

  }
  val myStream = 1 -->: 2 -->: 3-->: new MyStream[Int]

  // syntax sugar
  class TeenGirl(name:String){
    def `and then said`(gossip:String):Unit = println(s"$name said $gossip")
  }
  val lilly = new TeenGirl("Lilly")
  lilly `and then said` "Scala is awesome!!!"

  //syntax sugars #5: infix types

  class composite[A,B]
  val aComposite: composite[Int,String] = ???

  class -->[A,B]
  val towards: Int --> String = ???
  //syntax sugars #6: updates is very special, much like apply()
  val anArray = Array(1,2,3)
  anArray(2) = 7//rewritten to anArray.update(2,7)

  //syntax sugars #7: setters for mutable container
  class Mutable {
    private var internalMember:Int = 0 //private for OO encapsulation
    def member:Int = internalMember //getter
    def member_=(value:Int):Unit = //setter
      internalMember = value
  }
  val aMutableContainer = new Mutable
  aMutableContainer.member = 42


}

