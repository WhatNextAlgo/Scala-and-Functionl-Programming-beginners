package playground

object ScalaPlayground {
  def main(args: Array[String]): Unit = {
    println("Hello, Scala!!")
  }


}
