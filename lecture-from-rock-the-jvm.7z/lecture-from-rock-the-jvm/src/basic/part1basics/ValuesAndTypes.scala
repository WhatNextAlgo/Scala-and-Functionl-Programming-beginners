package basic.part1basics

object ValuesAndTypes {

  //values
  val meaningOfLife : Int = 45 // const int meaningOfLife = 42
  // reassigning is not allowed
  // meaningOfLife = 35

  //type inference
  val anInteger = 47

  // common types
  val aBoolean : Boolean = true
  val aChar : Char = 'A'
  val asInt : Int  =  45 // 4 bytes.
  val aShort : Short = 5379 // 2 bytes
  val aLong : Long = 52789572389234L // 8 bytes
  val aFloat : Float = 2.4f //  bytes
  val aDouble : Double = 3.14 // 8 bytes

  // string
  val aString: String = "Scala"

  def main(args: Array[String]): Unit = {

  }



}
