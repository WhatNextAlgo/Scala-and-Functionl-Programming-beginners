package basic.part2oop

object OOBasics {

  //Classes
  class Person(val name:String,age:Int){
    //fields
    val allCaps = name.toUpperCase()

    //methods
    def greet(name:String):String =
      s"$this.name says: Hi, $name"

    //signature differs
    //overloading
    def greet():String =
      s"Hi, everyone, my name is $this.name"

    //aux constructor
    def this(name:String)=
      this(name,0)

    def this()=
      this("Jon Doe",0)





  }
  val aPerson:Person = new Person("Sumit",28)
  val john = aPerson.name
  val johnSayHiDaniel = aPerson.greet("Daniel")
  val johnSayHi = aPerson.greet()
  val genericPerson:Person = new Person()

  /**
  Exercise: imagine we're creating a backend for a book publishing house.
  Create a Novel and a Writer class.
  Writer: first name, surname, year
    - method fullname
  Novel: name, year of release, author
    - authorAge
    - isWrittenBy(author)
    - copy (new year of release) = new instance of Novel
   */

  class Writer(firstName:String,lastName:String, val yearOfBirth:Int){
    def fullName:String = s"$firstName $lastName"

  }
  class Novel(title:String,yearOfRelease:Int,author:Writer){
    def authorAge:Int = yearOfRelease - author.yearOfBirth
    def isWrittenBy(author:Writer): Boolean= this.author == author
    def copy(newYear:Int):Novel = new Novel(title,newYear,author)
  }

  /**
   * Exercise #2: an immutable counter class
   * - constructed with an initial count
   * - increment/decrement => NEW instance of counter
   * - increment(n)/decrement(n) => NEW instance of counter
   * - print()
   *
   * Benefits:
   * + well in distributed environments
   * + easier to read and understand code
   */

  class Counter(count:Int = 0){
    def increment():Counter =
      new Counter(count + 1)

    def decrement():Counter = {
      if (count == 0) this
      else new Counter(count -1)
    }

    def increment(n:Int):Counter = {
      if (n <= 0) this
      else increment().increment(n + 1)
    }

    def decrement(n:Int):Counter = {
      if (n <= 0) this
      else decrement().decrement(n - 1)
    }

    def print():Unit =
      println(s"Current count: $count")

  }

}
