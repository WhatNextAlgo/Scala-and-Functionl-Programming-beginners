package com.company.bar.barbar;

public class Bar {
}
