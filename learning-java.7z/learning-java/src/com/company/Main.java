package com.company;


import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

//        char [] letters ={'A','A','B','C','D','D','D'};
//        int count  =  coutOccurrences(letters,'D');
//        System.out.println("count "+ count);

        Lens lenOne = new Lens("sony","85mm",true);
        Lens lenTwo = new Lens("canon","24-70mm",false);

        System.out.println("LenOne" + " - "+lenOne.brand  + " - "+lenOne.focalLength + " - "+lenOne.isPrime);
        System.out.println("LenTwo" + " - "+lenTwo.brand + " - "+lenTwo.focalLength + " - "+lenTwo.isPrime);



    }

    public static  int coutOccurrences(char [] letters,char searchLetter){
        int count = 0;
        for (char letter: letters) {
            if (letter == searchLetter){
                count++;
            }
        }
        return count;
    }

    static class Lens{
        String brand;
        String focalLength;
        boolean isPrime;

        Lens(String brand,String focalLength,boolean isPrime){
            this.brand = brand;
            this.focalLength = focalLength;
            this.isPrime = isPrime;
        }


    }
    static class Person{
        String name;

        Person(String name){
            this.name  = name;
        }
    }
}

