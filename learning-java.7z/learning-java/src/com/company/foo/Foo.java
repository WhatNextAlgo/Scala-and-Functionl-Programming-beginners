package com.company.foo;

public class Foo {


}
