package lectures.part2oops

object Generics extends App {

  class MyList[+A] {
    //Use the type A

    // type B >: (Supertype of ) A
    // What does that mean if I pass B which is supertype of A
    // then MyList turn into MyList[B] not MyList[A]
    def add[B >:A](element:B):MyList[B] = ???
    /*
    ex:
      A = Cat
      B = Dog = Animal
      Then B turn into MyList[Animal] because they are cats and Dogs now.
     */
  }

  class MyMap[Key,Value]
  val listOfIntegers = new MyList[Int]
  val listOfStrings = new MyList[String]

  // Generic Method
  object MyList{
    def empty[A]:MyList[A] = ???
  }
  val emptyListOfIntegers = MyList.empty[Int]

  // variance problems
  class Animal
  class Dog extends Animal
  class Cat extends Animal

  //1. Yes List[Cat] extends List[Animal] = COVARIANCE
  class CovariantList[+A]
  val animal:Animal = new Cat
  val animalList:CovariantList[Animal] = new CovariantList[Cat]
  // animal.add(new Dog) ??? Hard Question => we return list of animal

  //2. No, List[Cat] and List[Dog] are two separate thing
  // INVARIANCE
  class InvariantList[A]
  //val invariantAnimalList:InvariantList[Animal] = new InvariantList[Cat] throw error

  //3. Hell, no CONTRAVARIANCE
  class ContravariantList[-A]
  val contravariantList:ContravariantList[Cat] = new ContravariantList[Animal]

  class Trainer[-A]
  val trainer:Trainer[Cat] = new Trainer[Animal]

  // Bounded types
  class Cage[A <:Animal](animal: A)// Cage only accept A subtype(<:) Animal
  val cage = new Cage(new Dog) // this called upper bounded type

  // lower bounded type >:


  // expand MyList to be generic


}
