package lectures

package object part2oops {

  def sayHello:Unit = println("Hello, Scala")
  val SPEED_OF_LIGHT = 299792458

}
