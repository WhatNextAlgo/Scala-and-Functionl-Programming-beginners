package lectures.part2oops

import playground.{Cinderella => Princess, PrinceCharming}

import java.util.Date
import java.sql.{Date => sqlDate}


object PackagingAndImport extends App {
  // package members are accessible by their simple name.
   val writer = new Writer("Sumit","RockTheJVM",2018)

  // Import the package
  val princess = new Princess // playground.Cinderella   fulling qualified name

  // package are in hierarchy
  // matching folder structure

  // package object
  sayHello
  println(SPEED_OF_LIGHT)

  // import
  val prince = new PrinceCharming

  //1. Use FQ names
  val date = new Date
  val sqlDate = new sqlDate(2018,5,4)
  // 2. use aliasing

  // default import
  // java.lang - String, Object, Exception
  // Scala - Int, Nothing, Functions
  // scala.Predef  println , ???
}
