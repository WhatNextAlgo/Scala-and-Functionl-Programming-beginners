package lectures.part2oops

object Exceptions extends App {
   val x: String = null
  //println(x.length)
  // This ^^ crash with Null Pointer Exception

  // throwing amd catching exception
  //val aWiredValue: String = throw new NullPointerException

  //1.  throwable classes extend the Throwable class.
  // Exception and Error are the major Throwable subtypes

  // 2. How to catch exceptions
  def getInt(withException:Boolean):Int =
    if (withException) throw new RuntimeException("No int for you!")
    else 42

  val potentialFail = try{
    // code that might failed
    getInt(true)
  }catch{
    case e:RuntimeException => 43 //println("Caught a RunTime exception")

  } finally {
    // code that will get execute NO MATTER WHAT
    // optional
    // does not influence the return type of this expression
    // use finally only for side effect
    println("Finally")
  }
  println(potentialFail)

  // 3. How to define your own exception
  class MyException extends Exception{
    val exceptions = new MyException
    //throw exceptions

  }
  /*
    1. Crash your program without an OutOfMemoryError
    2. Crash with SOError
    3. PocketCalculator
      - add(x,y)
      - subtract(x,y)
      - multiple(x,y)
      - divide(x,y)

      Throw
        - OverFlowException if add(x,y) exceeds Int.MAX_VALUE
        - UnderflowException if subtract(x,y) exceed Int.MIN_VALUE
        - MathCalculationException for Division by zero
   */
  // OOM
  // val array = Array.ofDim(Int.MaxValue)

  // SO
  //def infinite: Int = 1 + infinite
  //val noLimit = infinite
  class OverflowException extends RuntimeException
  class UnderflowException extends RuntimeException
  class MathCalculationException extends RuntimeException("Division by 0")
  object PocketCalculator{
    def add(x:Int,y:Int) =  {
      val result = x + y
      if (x > 0 && y > 0 &&result < 0) throw new OverflowException
      else if (x < 0 && y < 0 && result > 0) throw new UnderflowException
      else result
    }

    def subtract(x:Int,y:Int) ={
      val result = x - y
      if (x > 0 && y < 0 && result < 0) throw new OverflowException
      else if (x < 0 && y > 0 && result > 0 ) throw  new UnderflowException
      else result
    }

    def multiple(x:Int,y:Int) ={
      val result = x * y
      if (x > 0 && y > 0 && result < 0) throw new OverflowException
      else if (x < 0 && y < 0 && result < 0) throw new OverflowException
      else if (x > 0 && y < 0 && result > 0) throw new UnderflowException
      else if (x < 0 && y > 0 && result > 0) throw new UnderflowException
      else result
    }

    def divide(x:Int,y:Int) = {
      if (y == 0) throw new MathCalculationException
      else x /y
    }
  }

  //println(PocketCalculator.add(Int.MaxValue,10))
  println(PocketCalculator.divide(2,0))

}
