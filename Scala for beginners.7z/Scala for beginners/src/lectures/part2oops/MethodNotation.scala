package lectures.part2oops

object MethodNotation extends App {

  class Person(val name:String,favoriteMovie:String,val age:Int = 0){
    def likes(movie:String):Boolean = favoriteMovie == movie
    def hangOutWith(person:Person) =  s"${this.name} is hanging out with ${person.name}"
    def +(person:Person) =  s"${this.name} is hanging out with ${person.name}"
    def +(nickname:String) =  new Person(s"$name ($nickname)",favoriteMovie)
    def unary_! : String =  s"${this.name}, What the heck?!"
    def unary_+ : Person =  new Person(name,favoriteMovie,age + 1)
    def isAlive:Boolean = true
    def apply(): String = s"Hi, my name is $name and I like $favoriteMovie"
    def apply(n:Int): String = s"$name watched $favoriteMovie $n times."

    def learns(thing:String) = s"$name is learning $thing"
    def learnsScala() = this.learns("Scala")

  }
  val mary = new Person("Mary","Inception")
  print(mary.likes("Inception"))
  println( mary likes "Inception") // infix notation = operator notation (syntactic sugar).Only works with single parameter

  // "Operator" in Scala
  val tom = new Person("Tom","Fight Club")
  println(mary hangOutWith tom)
  println(mary + tom)
  println(mary.+(tom))

  println(1 + 2)
  println(1.+(2))
  // ALL OPERATORS ARE METHODS.
  // Akka actors have ! ?

  // prefix notation
  val x = -1 // equivalent with 1.unary_-
  val y = 1.unary_-
  // unary_ prefix only works  with - + ~ !

  println(!mary)
  println(mary.unary_!)

  // postfix notation
  // method doesn't have any parameter can use in postfix notation
  println(mary.isAlive)
  println(mary isAlive)

  // apply
  println(mary.apply())
  println(mary()) // equivalent

  /*
    1. Overload the  + operator
    mary + "the rockstar" => new person "mary (the rockstar)"

    2. Add an age person class with default value = 0
       Add a unary + operator => new person with the age + 1
       +mary => mary with age increment

    3. Add a "learns" method in the person class => "mary learns scala"
       Add a learnsScala method, calls learns method with "Scala".
       Use it in postfix notation

    4. Overload the apply method
      mary.apply(2) => "Mary watched Inception 2 times."

   */
  //1 .
  println((mary + "the Rockstar")())
  //2.
  println("Age : ",(+mary).age)
  //3.
  println(mary learnsScala)
  //4.
  println(mary(2))



}
