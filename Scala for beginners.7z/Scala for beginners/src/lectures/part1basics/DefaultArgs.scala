package lectures.part1basics

object DefaultArgs extends App {

  def factorial(n :Int , acc :Int = 1):Int =
    if (n <= 1) acc
    else factorial(n - 1, acc * n)
  println(factorial(5))

  def savePictures(format:String = "jpg",width:Int = 1920,height:Int =  1080):Unit = println("saving picture.")
  savePictures("jpg",800,600)

  /*
    1. pass in every leading argument
    2. name the arguments
   */
}
