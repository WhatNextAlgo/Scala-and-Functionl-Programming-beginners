package lectures.part1basics

object CBNvsCBV extends App {

  def calledByValue(x:Long):Unit = {
    println("by value: " + x) //1405266383029100L
    println("by value: " + x) //1405266383029100L
  }

  def calledByName(x: =>Long):Unit = {
    println("by name: " + x) //System.nanoTime()
    println("by name: " + x) //System.nanoTime()
  }
  calledByValue(System.nanoTime())
  calledByName(System.nanoTime())

  def infinte(): Int =  1 + infinte()
  def printFirst(x:Int, y: => Int)= println(x)

  printFirst(34,infinte()) // infinite() execute when it is use.

}
