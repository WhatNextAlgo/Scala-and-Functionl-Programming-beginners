package lectures.part1basics

object ValuesVariablesTypes extends App {
  /* val <Variable Name> : <Type> = Value
     VAL ARE IMMUTABLE
     COMPILER can infer types
   */
  val x:Int = 42
  println(x)

  val aString:String = "Hello"
  val aBoolean:Boolean = true
  val aChar:Char = 'a'
  val anInt: Int = x
  val aShort: Short = 4565
  val aLong: Long = 6979797997979L
  val afloat:Float = 2.0f
  val aDouble:Double = 31324.353

  /* Variables
  VAR ARE MUTABLE
   */
  var aVariable:Int = 4
  aVariable = 5 // side effects


}
