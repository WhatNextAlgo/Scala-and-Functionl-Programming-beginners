package lectures.part3fp

object AnonymousFunctions extends App{

  // anonymous function (LAMBDA)
  val doubler: Int => Int = (x:Int) => x * 2
  //println(doubler)

  val adder :(Int,Int) => Int = (a:Int,b:Int) => a + b
  //println(adder(2,3))

  val justDoSomething:() => Int = () => 3
  println(justDoSomething) // function itself
  println(justDoSomething()) // call

  // curly braces with lambdas
  val stringToInt = { (str:String) =>
    str.toInt
  }
  // MOAR syntactic sugar
  val niceIncrementer: Int => Int = _ + 1 // equivalent x => x + 2
  val niceAdder: (Int,Int) => Int = _ + _ // equivalent (a, b) => a + b
  /*
   1. MyList replace all FunctionX calls with lambdas
   2. Rewrite the "special" adder as an anonymous function
   */

  val supper = (x:Int) => (y:Int) => (z:Int) => x + y + z
  println(supper(3)(5)(8))
}
