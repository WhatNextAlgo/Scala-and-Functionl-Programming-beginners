package playground

class Cinderella {

}
