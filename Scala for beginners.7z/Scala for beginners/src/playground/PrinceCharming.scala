package playground

class PrinceCharming {

}
