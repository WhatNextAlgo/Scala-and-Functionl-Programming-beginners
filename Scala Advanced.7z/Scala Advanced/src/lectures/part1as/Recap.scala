package lectures.part1as

import scala.annotation.tailrec

object Recap extends App {

  val aCondition:Boolean = false
  val aConditionedVal:Int = if (aCondition) 42 else 45
  //Instructions vs expression
  // Code-Block
  // compiler infers types for us
  val aCodeBlock = {
    if (aCondition) 54
    56
  }

  // Unit = void
  val theUnit = println("Hello,Scala")

  // functions

  def aFunction(x:Int):Int = x + 1

  // recursion: stack and tail
  @tailrec
  def factorial(n:Int,acc:Int = 1):Int =
    if (n <= 0) acc
    else factorial(n-1,acc * n)

  // object-oriented programming
  class Animal
  class Dog extends Animal

  val aDog:Animal = new Dog // Subtyping polymorphism

  trait Carnivore {
    def eat(a:Animal):Unit
  }

  class Crocodile extends Animal with Carnivore{
    override def eat(a: Animal): Unit = println("Crunch")
  }
  // method notation
  val aCroc = new Crocodile
  aCroc eat aDog // natural language

  // Anonymous classes
  val aCarnivore = new Carnivore {
    override def eat(a: Animal): Unit = println("rear!")
  }

  // generics
  abstract class MyList[+A] // Variance and variance problems in THIS course
  // Singletons and Companions
  object MyList

  // case classes
  case class Person(name:String,age:Int)

  // Exceptions and try/catch/finally

  val throwsException = throw new RuntimeException // Nothing
  val aPotentialFailure = try {
    throw new RuntimeException
  }catch {
    case e:Exception => "I caught an exception"
  }finally {
    println("some logs")
  }

  //package and imports

  // functional programming

  val incrementer = new Function[Int,Int] {
    override def apply(v1: Int): Int = v1 + 1
  }
  incrementer(1)

  val anonymousIncrementer = (x:Int) => x + 1
  List(1,2,3).map(anonymousIncrementer) // HOF
  //map, filter , flatmap

  // for-comprehension
  val pair = for {
    num <- List(1,2,3) // if condition
    char <- List('a','b','c')
  } yield num + "-" +char

  // Scala collection: Seqs, Arrays, Lists,Vectors, Maps, Tuples
  val aMap = Map(
    "Daniel" -> 789,
    "Sumit" -> 555
  )

  // "collection" : Option, Try
  val anOption =  Some(2)

  // Pattern Matching
  val x = 2
  val order= x match {
    case 1 => "first"
    case 2 => "second"
    case 3 => "third"
    case _ => x + "something else"
  }

  val bob = Person("Bob",21)
  val greeting = bob match {
    case Person(n,a) => s"Hello, my name is $n and I am $a years old."
  }

  // all the patterns

}
