package lectures.part5ts

object Variance extends App {

  trait Animal
  class Dog extends Animal
  class Cat extends Animal
  class Crocodile extends Animal

  // what is variance
  // "inheritance" - type substitution of generics

  class Cage[T]
  //yes - covariance
  class CCage[+T]
  val ccage:CCage[Animal] = new CCage[Cat]

  // no - invariance
  class ICage[T]
  //val icage:ICage[Animal] = new ICage[Cat] // wrong

  // hell no - opposite = contravariance
  class XCage[-T]
  val xcage:XCage[Cat] = new XCage[Animal]

  class InvariantCage[T](val animal:T) // invariant

  // covariant positions
  class CovariantCage[+T](val animal: T) // COVARIANT POSITION

  // Contravariant
  //class ContravariantCage[-T](val animal: T) // Error : Contravariant type T occurs in covariant position in type T of value animal
  /*
   if code compile then we can write
   val catCage:XCage[Cat] = new XCage[Animal](new Crocodile)
   */

  // class CovariantVariableCage[+T](var animal: T) // Covariant type T occurs in contravariant position in type T of value animal
  /*
    val ccage: CCage[Animal] = new CCage[Cat](new Cat) acceptable
    ccage.animal =  new Crocodile - not acceptable
   */

  // class ContravariantCage[-T](var animal: T) //Contravariant type T occurs in covariant position in type T of value animal
  /*
    val ccage: CCage[Cat] = new CCage[Animal](new Crocodile) not acceptable
   */

  class InvariantVariableCage[T](var animal: T) //ok

  /*
  trait AnotherCovariantCage[+T]{
    def add(animal:T) // Contravariant position
  }

  val ccage:CCage[Animal] = new CCage[Dog]
  ccage.add(new Cat)
   */

  class AnotherContravariantCage[-T]{
    def add(animal:T) = true
  }

  val acc:AnotherContravariantCage[Cat] = new AnotherContravariantCage[Animal]
  acc.add(new Cat)
  class Kitty extends Cat
  acc.add(new Kitty)

  class MyList[+A] {
    def add[B >: A](element:B):MyList[B] =  new MyList[B] // widening the type
  }
  val emptyList=  new MyList[Kitty]
  val animal = emptyList.add(new Kitty)
  val moreAnimal = animal.add(new Cat)
  val evenMoreAnimal = moreAnimal.add(new Dog)

  // METHOD ARGUMENTS ARE IN CONTRAVARIANT POSITION

  //return Types
  class PetShop[-T]{
//    def get(isItaPuppy:Boolean):T = ??? // METHOD RETURN TYPES ARE IN COVARIANT POSITION
    /*
      val catShop = new PetShop[Animal] {
        def get(isItaPuppy:Boolean):Animal = new Cat
      }
      val dogShop:PetShop[Dog] = catShop
      dogShop.get(true) // EVIL CAT!

     */

    def get[S <: T](isItaPuppy:Boolean, defaultAnimal:S):S = defaultAnimal
  }

  val shop:PetShop[Dog] = new PetShop[Animal]
  //val evilCat = shop.get(true,new Cat) // illegal;

  class TerraNova extends  Dog
  val bigFurry = shop.get(true,new TerraNova);
  /*
    Big Rule
    - method arguments are in CONTRAVARIANT position
    - return types are in COVARIANT position
   */

  /**
   * Invariant, Covariant,Contravariant
   *  Parking[T](things: List[Int] {
   *    park(vehicle:T)
   *    impound(vehicle:List[T])
   *    checkVehicles(conditions:String):List[T]
   *  }
   *
   * 2. used someone's else API: IList[T]
   */
  class Vehicle
  class Bike extends Vehicle
  class Car extends Vehicle

  class IList[T]

  class IParking[T](vehicles: List[T]){
    def park(vehicle: T):IParking[T] = ???
    def impound(vehicle: List[T]):IParking[T] = ???
    def checkVehicles(conditions: String):List[T] = ???

    def flatMap[S](f:T => IParking[S]):IParking[S] = ???
  }

  class CParking[+T](vehicles: List[T]){
    def park[S >: T](vehicle:S):CParking[S] = ???
    def impound[S >: T](vehicle: List[S]):CParking[S] = ???
    def checkVehicles(conditions: String):List[T] = ???

    def flatMap[S](f:T => CParking[S]):CParking[S] = ???
  }

  class XParking[-T](vehicles: List[T]){
    def park(vehicle: T):XParking[T] = ???
    def impound(vehicle: List[T]):XParking[T] = ???
    def checkVehicles[S <: T](conditions: String):List[S] = ???

//    def flatMap[R <:T,S](f:Function1[R,XParking[S]]):XParking[S] = ???
    def flatMap[R <:T,S](f:(R) => XParking[S]):XParking[S] = ??? // Syntactic sugar
  }

  /*
    Rule of thumb
      - use covariance = Collection of things
      - use contravariance = group of actions
   */

  class CParking2[+T](vehicles: IList[T]){
    def park[S >: T](vehicle:S):CParking2[S] = ???
    def impound[S >: T](vehicle: IList[S]):CParking2[S] = ???
    def checkVehicles[S >: T](conditions: String):IList[S] = ???
  }

  class XParking2[-T](vehicles: IList[T]){
    def park(vehicle: T):XParking2[T] = ???
    def impound[S <: T](vehicle: IList[S]):XParking2[S] = ???
    def checkVehicles[S <: T](conditions: String):IList[S] = ???
  }

  //



}
