package lectures.part3concurrency


object ParallelUtils extends App {

}
